## 1.5.11 — Updated Hub History support

- Supports the October mixed History table without an Unsigned dropdown.
- Starts from page 1 and uses individual Sign buttons across History pages.
- Does not activate the new Sign all button, preserving per-transaction fee review.
- Keeps existing per-account ledgers, gas limit, retry flow and epoch cache.
- Skips rows without a reliable attempt ID.
- Rejects inconsistent or ignored history-filter totals instead of showing false counts.
- Legacy Unsigned dropdown remains supported.

Update the files in your existing unpacked extension folder, click Reload on
chrome://extensions (or brave://extensions), then reload the Hub tab once.
Keep the same extension installation to retain its saved ledgers and counters.

Validated against the History bundle captured in the supplied HAR and local
regression tests. The HAR contains no completed signing transaction; live
wallet confirmation and signing have not been tested in this environment.

# Axis Auto Sign 1.5.11

- Gas notunda eşit yükseklikte rakamlar için Segoe UI kullanıldı.
- Ücret sınırı aynı: $0.01.

# Axis Auto Sign 1.5.9

- Delay rakamları Segoe UI ve eşit genişlikte rakamlarla düzenlendi.
- Gas koruma yazısı ortalandı. Signed/Failed ve queue etiketleri/sayıları
  1 px büyütüldü; queue satır ve sütun aralıkları açıldı.

# Axis Auto Sign 1.5.8

- Altın imza 9 px olarak güncellendi.

# Axis Auto Sign 1.5.7

- Popup açılınca önce queue toplamları, ardından epoch verileri hazırlanır;
  Progress'e tıklamayı beklemez. Beş dakikadan yeni geçmiş önbelleği tekrar taranmaz.
- İlk kullanımda tüm history kaydedilir. Normal Scan yalnızca son epochu yeniler;
  eski epochlar hesap bazında saklanır. Full scan tümünü yeniler.
- İmzalama veya hesap hazırlığı sürüyorsa otomatik tarama bitmesini bekler.
- Progress açılırken hazırlanmış veri korunur; tekrar bağlantı/tarama başlatılmaz.
- Altın imza fontu 11 px'ten 10 px'e küçültüldü.

# Axis Auto Sign 1.5.6

- Progress: Hub NEW etiketiyle aynı #48ff88 zemin, siyah Borna Bold yazı.
- Sayaç ve metrik başlıkları daha kalın.

# Axis Auto Sign 1.5.5

- Siyah zemin üzerinde #1f1f1f gri kartlar ve beyaz yazılar.
- Kart/tuşların açık gri sınırları kaldırıldı; klavye odak göstergesi korundu.
- Yeşil/turuncu büyük tuş yüzeyleri gri oldu. Unsigned ve ilerleme göstergeleri
  Hub yeşili #48ff88 kullanır. Signed sayıları altın renginde kalır.
- İmza alt boşluğun ortasında, daha büyük Press Start 2P fontu ve parlak altın.
- Bu sürüm yalnızca görünümü değiştirir; tarama ve imzalama davranışları aynı.

# Axis Auto Sign 1.5.4

- YouTube gibi başka sekmede START: tek açık Hub sekmesi arka planda hedeflenir.
  Birden çok Hub varsa istenen hesabın sekmesinden başlatılmalıdır. Hub kapalıysa
  işlem başlamaz. Başka sekme Hub URL'sine dönüştürülmez, odak çalınmaz.
  Tarayıcının sekmeyi uyutması veya cüzdan etkileşimi çalışmayı geciktirebilir.

- Hub CSS ile aynı siyah (#000), Borna Regular/Medium/SemiBold/Bold fontları.
- Altın footer alt kenara hizalandı.
- Scan: ilk kullanımda geçmişi oluşturur; aynı hesabın önbelleği varsa yalnızca
  son başlamış epochu yeniler. Eski epoch kayıtları korunur. Tarih sınırını bulmak
  için sınırı içeren son API sayfası da okunur, eski kayıtlar güncellenmez.
- Full scan: tüm geçmişi yeniden okur. Scan düğmesi beş dakikalık önbellek
  nedeniyle atlanmaz. Yeni epochlar özet API cevabından otomatik eklenir.
- NEXT sayfa/History filtresini değiştirmez. Sayılar filtreli API toplamlarından
  gelir. START imzalama için History/Unsigned görünümüne geçebilir.
- Eski epochta geç gelen yeni kayıt toplamı değiştirirse Full scan istenir.

# Axis Auto Sign 1.5.3

- Popup 360 px yerine 330 px genişliğinde.
- Footer ve her iki Signed sayacı altın renginde; Unsigned yeşil.
- Ana ekrandaki API etiketleri kaldırıldı.
- Hazır delay seçenekleri 1.7 / 2 / 2.5 saniye. Yeni kurulum varsayılanı 1.7.
- Eski 1.5 saniyelik hazır seçim 1.7'ye yükseltilir. Kayıtlı 2 / 2.5 ve custom
  tercihleri korunur. Custom ile daha düşük değer girilebilir.
- Unsigned/Pending/Signed/Failed toplamları küçük filtreli isteklerden okunur.
  Epoch sayıları ve skorlar ilk seferde sayfalı API geçmişinden hesaplanıp
  önbelleğe alınır. Sonraki hızlı tarama güncel ve son dağıtılmış epochu yeniler.

# Axis Auto Sign 1.5.2 — Popup içi Progress

- Kompakt 360 × 560 popup, küçük Borna fontu ve iki sütunlu sayaçlar.
- Progress aynı popup içinde açılır; Back ana ekrana döner. Yeni sekme açılmaz.
- Epoch seçicisinde başlangıç/bitiş tarihleri, dağıtılmış toplam point,
  trajectory sayısı, farklı task sayısı ve sayısal skorların ortalaması gösterilir.
- Güncel epoch varsayılan seçilir. Kalan süre API bitiş tarihinden hesaplanır.
- Progress açılınca hesap doğrulanır; geçmiş yoksa veya beş dakikadan eskiyse
  otomatik senkronizasyon başlar. İlk tarama boyunca eksik toplam gösterilmez.
- Queue sayaçları güncelleniyorsa Progress bekler. İmzalama aktifse senkronizasyon
  ertelenir; durdurduktan sonra Sync / resume kullanılabilir.
- Sync / resume son taramayı sürdürür; Full rescan tüm geçmişi yeniler.
  Popup kapanınca devam eden tarama Hub sekmesinde sürer.
- Pending pointler tahmin edilmez. Tarihler yerel saat diliminde gösterilir.

## Kurulum

ZIP'i çıkarın. Chrome → Extensions → Developer mode → Load unpacked ile
manifest.json dosyasının bulunduğu klasörü seçin. Mevcut klasörü güncelliyorsanız
Reload'a basın. Ardından Axis Hub sekmesini yenileyin.

## Kontroller

Node testleri: epoch sınırları, hesap izolasyonu, API filtreleri, 429 beklemesi,
checkpoint/sürdürme ve popup içi epoch seçimi. Bu ortamda gerçek Chrome popup
boyutu görsel olarak doğrulanamadı.

---

# Axis Auto Sign 1.5.1 — API History Totals

## Bu sürümde değişenler

Unsigned / Pending / Signed / Failed / All toplamları artık sitenin kendi History
API filtrelerinden alınır. Doğrulanan sorgu biçimi:

`/api/me/history?page=1&limit=20&filter=unsigned`

Diğer gerçek filtreler: `signed`, `pending`, `failed`. All için filter gönderilmez.
Cevaptaki `total` kullanılır. Sayım amacıyla filtreye tıklama, son sayfaya gitme,
veya sayfa sayısı × 20 tahmini kaldırıldı. İmzalama arayüzü ve işlem onayı hâlâ
mevcut DOM/cüzdan akışını kullanır; gas koruması ve duplicate ledger korunur.

## Otomatik güncelleme

- Popup açılınca aktif Hub sekmesindeki hesap API ile doğrulanır.
- O hesap için önbellek varsa gösterilir. İki dakikadan eskiyse sayaçlar arka
  planda otomatik yenilenir. İlk kullanımda birkaç saniye sürebilir.
- Beş toplam için beş küçük history isteği yapılır, bütün geçmiş indirilmez.
- Popup ve Stats açıkken yapılan durum yoklamaları yereldir; sürekli API polling yoktur.
- Güncelleme tek sıra halinde ve mevcut 429/Retry-After kuyruğuyla yapılır.
- İmzalama veya epoch taraması çalışıyorsa sayaç yenileme ertelenir. İş bittikten
  sonra popup'ı yeniden açın veya sayaçların yanındaki yenileme düğmesine basın.
- Başarılı/duplicate kayıtlar unsigned sayısından aynı attempt ID için yalnızca
  bir kez düşülür. Bu yerel düzeltme `≈` olarak etiketlenir. Signed/Pending/Failed
  sayaçları son API snapshot'ıdır. Sunucu gecikmesi varsa API toplamı da gecikebilir.
- Aynı anda birden çok Hub sekmesi varsa istenen hesap sekmesini öne alıp popup'ı açın.
- Server response anına ait toplam kesin okunur; beş ayrı istek atomik bir sunucu
  snapshot'ı değildir. Veri hareketliyse toplamlar farklı anlara ait olabilir.

## Epoch Stats

Canlı API sayaçları ayrı bölümde görünür; tam epoch history taraması gerektirmez.
`verified` adında doğrulanmış bir API filtresi yoktur; verified flag sayısı yalnızca
history snapshot'ından gelir. Signed ile verified birbirinin yerine kullanılmaz.
Epoch içindeki unsigned adayı kuralı da sitenin sign-button kuralıyla düzeltildi:
`pass_verify=true && chain_data present && !txhash`.
1.5.0 önbelleğinde chain_data varlığı saklanmadığından bu tarihsel aday alanı
Full rescan yapılana kadar — görünebilir; canlı unsigned API sayısı etkilenmez.

## Güncelleme

İmzalamayı durdurup mevcut işlem sonucunu bekleyin. Mevcut eklenti klasörünün
şimdiki dosyalarını bu paketteki axis-sign-bot içeriğiyle güncelleyin.
chrome://extensions → Yenile; açık Hub sekmesini de bir kez yenileyin.
Eklentiyi kaldırmayın; böylece aynı eklenti kimliğindeki yerel ledger korunur.
Sürüm 1.5.1 olmalı.

## Testler

```
node tests/queue-counts.test.cjs
node tests/stats.test.cjs
node tests/read-api.test.cjs
```

Filtre sorguları, server total, cache, hesap değişimi, duplicate yerel düşüş,
429'da eksik sayaç kaydetmeme, imzalarken erteleme ve sekmeler arası kilit test edildi.
Canlı hesabınızda API/gerçek imza testi ve bu ortamda tarayıcı görsel testi yapılmadı.

---

## 1.5.0 ve daha eski sürüm notları (yukarıdaki değişiklikler önceliklidir)

# Axis Auto Sign 1.5.0 — Epoch Stats

## Kurulum / güncelleme

1. Çalışan imzalamayı STOP ile durdurun; mevcut işlemin sonucunu bekleyin.
2. ZIP'i çıkarın. Mevcut eklentiyi kaldırmadan, daha önce yüklediğiniz klasörün
   içeriğini bu paketteki `axis-sign-bot` klasörü içeriğiyle güncelleyin.
3. `chrome://extensions` içinde eklentinin Yenile düğmesine basın.
4. Açık Axis Hub sekmesini bir kez yenileyin. Eklenti sürümü 1.5.0 olmalı.
5. Eklentiden **Epoch Stats** açın. Yeni bir istatistik sekmesi açılır;
   yeni Hub sekmesi açılmaz, otomatik imzalama başlamaz.
6. Doğru Hub sekmesini seçin, Connect ve ardından Sync / resume kullanın.

Aynı eklenti kimliği ve klasörü korunursa eski imza defteri ve ayarlar korunur.
Eklentiyi kaldırıp yeniden kurmak yerel koruma kayıtlarını silebilir.

## Yeni özellikler

- Pakette zaten bulunan Borna fontu; daha büyük yazılar, okunabilir rakamlar.
- Epoch listesi: trajectory, farklı task ID sayısı, ortalama skor, tamamlanma,
  doğrulama durumları ve API'den task/referral/toplam point.
- Başlama/bitiş tarihleri ve mevcut epoch geri sayımı gerçek API tarihlerinden.
  Yeni epochun tarihleri API'de yoksa tahmin üretilmez. Connect özeti yeniler.
- İlk tarama tüm kişisel geçmişi 100'lük sayfalarla okur. 50.000 kayıt üstünde
  eksik veriyi tamamlanmış gibi göstermek yerine durur.
- Sonraki Quick sync, son settled epoch başlangıcından itibaren kayıtları
  yeniden okur, daha eski kayıtları önbellekten alır. Son 5 dakikanın tamamlanmış
  önbelleği tekrar taranmaz. Full rescan bunu atlayıp bütün geçmişi yeniler.
- Tam tarama bitmeden yeni eksiksiz toplam kaydedilmez. Eksik tarama ayrı
  checkpoint olarak saklanır. Sekme kapandıysa yeniden açıp Sync / resume
  ile devam edilebilir; baştaki kayıtlar/toplam değiştiyse yeniden başlar.
- Önbellek kullanıcı ID'sine göre ayrıdır. Başka hesaba geçince Connect gerekir.
- Pending, verified, hash taşıyan kayıt ve unsigned adayları aynı history
  cevabından hesaplanır; her filtre için ayrıca sayfa dolaşılmaz.

## API yükü / 429

Okuma istekleri sıraya alınır; başlangıçları arasında en az yaklaşık 1,2 saniye
bırakılır. Hub sekmeleri ortak bir okuma kilidi ve cooldown kullanır. 429'daki
Retry-After (saniye veya tarih) saklanır; belirtilmemişse 60 saniye beklenir.
İstatistik taraması 429'da durur; cooldown sonrası Sync / resume gerekir.
Tekrarlanan 429 sayfasında imzalama kurtarma beklemesi 30/60/120/240/300 saniyedir.
İstatistik taraması ile imzalama/hesap yenileme aynı anda başlatılmaz.
Hub'ın kendi istekleri ve cüzdan/RPC trafiği bu okuma kuyruğunun dışındadır;
bu nedenle sıfır 429 garantisi yoktur. İlk tarama hızlı değil, eksiksiz olmayı hedefler.

## Sayıların anlamı ve sınırlar

- Trajectory = attempt kaydı; aynı görevin tekrarları dahildir.
- Unique tasks = farklı task_id. Bunlar trajectory ile aynı sayı değildir.
- Average score = dönem içindeki sayısal score değerlerinin ortalaması;
  başarısız denemeler dahildir, null skorlar hariç, 0 skorlar dahildir.
- Dönem: completed_at, yoksa created_at; başlangıç dahil, bitiş hariç.
- Task point, referral ve total API settlement değeridir. Pending döneme
  tahmini point veya tahmini Challenger 2x/3x çarpanı yazılmaz.
- verified=true, pass_verify=true ve txhash bulunması ayrı sayılır.
- Pending verification: pass_verify yok ve verified true değil.
- Unsigned candidates: completed + pass_verify=true + txhash yok.
  Bu sayı sitenin kesin Unsigned kuyruğu değildir; backend gecikmesi, kopyalar,
  ödül uygunluğu ve eski epochta sonradan imzalama sonucu değiştirebilir.
- Kanalı açıkça bnwallet/bitrobot olan kayıtlar Axis epoch metriklerinden
  çıkarılır. Kanal alanı olmayan kayıtlar tarihle dahil edilir. Görev başına
  settlement bağı bulunmadığından bu metrikler ödül uygunluğunu kanıtlamaz.
- Snapshot toplamları tüm history kayıtlarını ve tüm kanalları içerir.
- API pages, 100 kayıt/istek üzerinden hesaplanır; sitenin UI sayfa sayısı değildir.
- Quick sync eski epoch durumlarını yeniden taramaz. Eski görevleri sonradan
  imzaladıysanız Full rescan kullanın. Taramada yeni görev üretmeyin.
- Tarihler tarayıcı saat diliminde, üzerlerine gelince UTC olarak görünür.
- Veriler sadece Chrome yerel deposundadır; analitik veya dışarı veri gönderimi yoktur.

## Doğrulama

Node.js ile:

```
node tests/stats.test.cjs
node tests/read-api.test.cjs
```

Testler: dönem sınırları, boş/sıfır skor, tekrar sayfa, checkpoint devam,
hesap ayrımı, hızlı sync sırasında eski sayfaların atlanması ve Retry-After.
Canlı Axis hesabında veya gerçek para içeren imza akışında test yapılmadı.
Otomatik tarayıcı görsel testi bu ortamda tarayıcı kurulamadığı için tamamlanamadı.

---

## Önceki sürüm notları (arşiv)

# Little Hub 1.3.2

## Güncelleme
STOP'a basıp mevcut işlem sonucunu bekleyin. Axis sekmelerini kapatın.
Dosyaları mevcut uzantı klasörüne kopyalayıp chrome://extensions üzerinden aynı
uzantıyı yenileyin. Uzantıyı kaldırmak ID geçmişini siler.

## Görünüm ve turlar
Axis TTF ve yazı boyutları korunur; popup 340 px genişliğindedir.
Üstte yalnızca SIGNED solda ve sarı FAILED sağdadır. DUPLICATED bilgi kartında
PENDING satırının altındadır. Pending gridir.
START SIGN FAILED, START/STOP satırının hemen üstündedir. Ek düğme için kart
boşlukları azaltıldı; CSS'te eklenen 30 px alan kadar dikey boşluk geri kazanıldı.
Gerçek tarayıcıda boyut/görünüm ölçümü bu ortamda yapılamadı.

START: yeni Unsigned ID'leri işler; kayıtlı başarısızları sonraki tura saklar.
Mevcut sayfalar bitince durur ve kalan Failed sayısını gösterir.
START SIGN FAILED: kalıcı kayıttaki doğrulanmış başarısız işleri ayrı turda dener.
Her düğmeye basışta her ID en fazla bir defa denenir. Başarılı olanlar kuyruktan
çıkarılır; tekrar başarısız olanlar sonraki düğmeye basış için kaydedilir.
Üçüncü/dördüncü ve sonraki turlar elle başlatılabilir; otomatik sonsuz retry yoktur.
Düğme kuyruk boşken veya başka işlem/refresh sürerken kapalıdır.
İşin Unsigned'da Sign düğmesiyle görünmesi gerekir. Görünmeyen ID kayıtta kalır.

Başarılı/duplicate ID'ler ve sonucu belirsiz gönderimler yeniden onaylanmaz.
Approve öncesinde ID geçici olarak diske yazılır. `nonce too low` hatası Axis/Privy'nin
hızlı ardışık approve sırasında önceki nonce'u kullanması olarak ele alınır: transaction
başarılı sayılmaz, ID FAILED/retryable kuyruğuna taşınır ve yalnızca START SIGN FAILED
ile sonraki turda yeniden denenebilir. `already known`, timeout ve network error gibi
sonucu gerçekten belirsiz durumlar duplicate gas riskine karşı retry listesine girmez.
FAILED görünen sayı, güvenle tekrar denenebilir benzersiz ID sayısıdır. RESET STATS başarılı ID'leri ve retry kuyruğunu silmez.

## Profil resmi
Profilde Edit düğmesi yanındaki ad bulunur. Aynı profil bloğundaki
svg[role="img"][viewBox="0 0 80 80"] alınır; Discord/X ikonları seçilmez.
SVG yalnızca gerekli çizim öğeleri ve yerel filtrelerle kopyalanır, resim olarak
adın solunda gösterilir. Görsel her profil okumasında yeniden alınır. Kullanıcı
resmi bulunamazsa gizlenir. Keyfi HTML popup'a eklenmez. Bu sürüm verilen SVG
profil tipini destekler; farklı resim/HTML türleri ek uyarlama gerektirebilir.
Points için gönderilen HTML'deki Points kartı da desteklenir.

## REFRESH
Refresh artık yalnızca profil bilgisini (avatar, kullanıcı adı, PTS/API profil verisi) yeniler.
History filtrelerine veya pagination'a dokunmaz; bütün Unsigned sayfalarını saymaz.
okunur. Signed/Duplicated istatistikleri ve imza geçmişi sıfırlanmaz. Failed
kuyruğu kayıttan yeniden hesaplanır. Güncelleme saati veya okunamayan alan hatası gösterilir.
İmza sırasında istek sıraya alınır; mevcut işlemin sonucu beklendikten sonra
uygulanır. Aktif işlem sırasında filtre değiştirilmez. Peş peşe tıklamalar tek
istekte birleşir. Refresh bitene kadar yeni START ve RESET kapalıdır.
Sayfanın tamamı reload edilmez. Ekran/filtrelerin sunduğu veriler ve mevcut profil
API'si okunur; sunucunun eski verisi zorla güncellenemez. Uzun işlem ve yüksek gas
beklemesi sırasında sıradaki refresh gecikebilir.

## Wallet ve toplamlar
TOTAL SIGNED sitenin Signed toplamından başlar ve başarılarla artar; RESET bunu
sıfırlamaz. Site gecikirse sonraki okuma farklı bir toplam gösterebilir.
Wallet'tan başarı modalındaki okunabilen tahmini ücret anında düşülür. Yaklaşık
bakiye ≈ ile gösterilir. Site bakiyesi işlem aralarında en fazla 30 saniyede bir
okunur; REFRESH elle okuma ister. Sitede USD varsa yaklaşık karşılık gösterilir.
RPC/banka bakiyesi sorgusu yapılmaz; site gecikmesi ve okunamayan başarısız işlem
ücretleri nedeniyle kesin bakiye garantisi yoktur.
$0.01 ücret sınırı, yüksek gas için 5 dakika bekleme, duplicate kaydı ve önceki
429 toparlama davranışı korunur.

## Doğrulama
Sayaçlar, toplamlar, bakiye uzlaştırma, tekrar sınırı, refresh isteklerinin birleşmesi,
istatistiklerin korunması, JS sözdizimi ve popup bağlantıları kontrol edildi.
Canlı Axis işlemi ve gerçek tarayıcı görsel testi bu ortamda yapılmadı.

1.2.5 kontrolleri: manuel 2/3/4. tur, aynı turda tek deneme, yeni/başarılı/belirsiz
IDlerin failed turundan dışlanması, boş kuyrukta düğmenin engellenmesi doğrulandı.


## 1.2.7 kompakt görünüm
Refresh artık PTS'nin sağındaki 24 px ikon düğmesidir. Yenilerken ikon döner;
son güncelleme bilgisi üzerine gelince görünür. Hata CURRENT alanında gösterilir.
Ayrı refresh düğme/saat satırları kaldırıldı. Genişlik 320 px, ana yazılar 7 px,
büyük rakamlar 14 px oldu. Axis TTF, sarı Failed ve Pending altındaki Duplicated
korundu. Boşluklar küçültüldü; içeriği gizlemek veya scrollbar'ı saklamak için
bir CSS kuralı eklenmedi. İmzalama/tekrar mekanizması değiştirilmedi.
Gerçek Chrome popup yüksekliği bu ortamda ölçülemedi; ekran ölçeklendirmesi
ve tarayıcı koşulları görünümü etkileyebilir.


## 1.2.8 profil fotoğrafı düzeltmesi
Verilen gerçek hesap HTML'indeki img[alt="User Avatar"] artık okunur.
Profil bloğundaki HTTPS fotoğrafı (X/Discord vb.) adın solunda gösterilir.
Resim yoksa önceki SVG avatar desteği kullanılır. Kopyalama ve sosyal ikonlar
fotoğraf olarak seçilmez. Yeni tarayıcı izni eklenmedi.
Fotoğraf adresi sunucuda erişilemezse kırık resim gizlenir; sonraki profil okuması
(Refresh/START) yeniden yüklemeyi dener. Fotoğrafın uzak sunucudan yüklenebilmesi
kullanıcının bağlantısına bağlıdır. 1.2.7 kompakt arayüz korunmuştur.

AXIS ROBOTICS başlığı Borna SemiBold 16 px; içerik Axis TTF olarak korunur.


## 1.2.9 nonce / FAILED düzeltmesi
Privy hata modalındaki `nonce too low: next nonce ..., tx nonce ...` artık `uncertain`
değil FAILED/retryable olarak sınıflanır. Normal tur aynı ID'yi o turda tekrar denemez;
START SIGN FAILED sonraki turda tekrar deneyebilir. Hata modalı kapandıktan sonra yalnızca
nonce hatasında 1.5 saniyelik kısa sync beklemesi uygulanır; başarılı sign akışı yavaşlatılmaz.

v1.2.8'de `uncertain` olarak kaydedilmiş ve mesajında `nonce too low` bulunan eski ID'ler
ilk çalıştırmada otomatik olarak retryable/FAILED kuyruğuna taşınır. Gerçek başarıyla
`signed` olmuş ID'ler ve backend'in tekrar Unsigned'a düşürdüğü duplicate ID'ler korunmaya
devam eder ve yeniden approve edilmez.


## 1.3.1 robust FAILED capture
Privy `Retry transaction` hata modalı artık yalnızca tek satırlık hata metnine bağlı değildir.
`#privy-modal-content` MutationObserver ile yakalanır; `nonce too low` ham modal metninden
doğrudan tespit edilir ve FAILED/retryable kuyruğuna yazılır. Privy'nin genel
`Missing or invalid parameters` hatası da Retry transaction modalında güvenli retry olarak
sınıflanır; olası broadcast durumları (`already known`, timeout/network/replacement) uncertain
olarak korunur. Extension güncellemesinden sonra eski Hub sekmesinde eski content script kalması
önlenir: START, popup ile worker script sürümünü karşılaştırır ve yalnızca arka plandaki Axis
sekmesini gerekirse bir kez reload ederek güncel kodu yükler.

## v1.3.1
- Refresh ikonu AXIS ROBOTICS başlığının sağına taşındı.
- Refresh yalnızca profil/PTS bilgisini yeniler; History ve pagination taraması yapmaz.
- UNSIGNED yaklaşık gösterilir: görünür pagination toplamı × 20 (`≈`).
- Site balance/meta satırı kaldırıldı; kartta yalnız WALLET / CAN SIGN / ELAPSED kaldı.


## v1.3.2 account safety
- ACCOUNT REFRESH updates the active profile/account without page-by-page History counting.
- Duplicate ledgers are namespaced per wallet/account; returning to an account restores its protected IDs.
- Account Refresh that encounters HTTP/page 429 stops immediately and shows a 60-second retry notice.
- The active account's ledger is mirrored to `submittedIds` only for backward compatibility.


v1.3.7: START/START SIGN FAILED capture the exact active tab from the popup and navigate that same tab to Hub; START never creates a new tab.


v1.3.9: Fixed content-script/manifest version mismatch so START no longer misidentifies the current worker as stale; background-tab signing behavior is unchanged.


## 1.4.0 FAILED classification
- Any visible Privy `Retry transaction` modal after Approve is recorded as FAILED/retryable.
- `nonce too low`, `replacement transaction underpriced`, generic `Missing or invalid parameters`, RPC/network/timeout errors shown in that modal are no longer placed in uncertain.
- Only explicit duplicate/already-signed/already-processed trajectory messages are classified as DUPLICATED and permanently protected.
- Account-scoped ID ledgers are unchanged: signed, failed and duplicate IDs remain saved per account/wallet; RESET STATS never deletes duplicate protection.
- Older uncertain entries matching known Privy/RPC failure reasons are migrated into the FAILED retry queue.


## 1.4.1 FAILED page-aware repair
- Every retryable failure stores the Unsigned page number where its trajectory ID failed.
- START SIGN FAILED always returns to page 1 first, then visits saved failed pages.
- Older failures without a saved page are located once; moved IDs get one fallback lookup.
- FAILED repair is finite: when the queue pass ends it stops with “Failed sign process completed” and never falls into normal signing.


## 1.4.2 success modal close fix
- Success detection now ignores hidden/stale Privy "All Done" buttons left mounted in the DOM.
- Completion closes are scoped to the visible success modal.
- Fallback close order: All Done -> modal X -> Escape.
- A transaction already recorded as successful is never re-submitted because of this close-recovery path.


## v1.4.3
- Added persistent 1s / 3s / 5s DELAY selector under START.
- The selected delay is applied between completed sign attempts in both normal and FAILED repair modes.
- Default is 3 seconds.


## v1.4.4
- Added CUSTOM sign delay beside 1S / 3S / 5S.
- Custom delay accepts 1-10 seconds, is persisted, and is used by both normal and failed-sign runs.


## v1.4.5
- Fixed false `Stopped: success modal stuck` when the Axis tab is in the background.
- Modal close detection now reacts to DOM mutations instead of relying only on short polling timers.
- Timer waits perform a final live DOM check after Chrome background-tab throttling.
- Applied the same background-safe close detection to Privy error modals.


## v1.4.6
- Restored the Web Lock background keep-alive that had been lost during refactors.
- Success-modal cleanup no longer HALTs the run when a hidden/background tab delays Privy UI state.
- After a confirmed success, the bot keeps safely retrying All Done / close / Escape until the visible success modal clears, then continues.
- Confirmed-success IDs remain protected in the account ledger throughout recovery.


## v1.4.7
Delay presets changed to 1.5s / 2s / 2.5s plus Custom. Custom accepts 1.0–10.0 seconds with one decimal place. Default delay is 2s.


## v1.4.8
- Custom delay input widened.
- Removed number spinner controls.
- Accepts dot or comma decimals (for example 1.5 or 1,5).
- Custom delay must be greater than 0 and is capped at 5 seconds.
