/* Matches PortfolioHistoryTab: filter=unsigned|signed|pending|failed, limit=20.
 * These are server totals, not page-count estimates or reward eligibility. */
(() => {
  if(globalThis.AxisQueueCounts)return;
  let account=null, snapshot=null, busy=false, error='', deferred=false;
  const cacheKey=id=>'axisQueueCounts:v1511:'+id;
  const TTL=120000;
  async function json(path){
    const r=await AxisReadAPI.request(path);
    if(!r.ok)throw new Error(`HTTP ${r.status}${r.status===429?' — waiting for cooldown':''}`);
    return r.json();
  }
  async function identify(raw){
    const me=raw?.data||raw;
    const id=me?.id??me?.user_id;
    if(id==null)throw new Error('Cannot identify account for history counts.');
    const next=String(id);
    if(account?.id!==next){snapshot=null;account={id:next,name:String(me.username||next)};snapshot=(await chrome.storage.local.get(cacheKey(next)))[cacheKey(next)]||null;}
    else account.name=String(me.username||next);
    return account;
  }
  function view(){
    const removed=Object.keys(snapshot?.resolved||{}).length;
    return {account,snapshot:snapshot?{counts:snapshot.counts,updatedAt:snapshot.updatedAt,
      unsigned:Math.max(0,snapshot.counts.unsigned-removed),unsignedPages:Math.ceil(Math.max(0,snapshot.counts.unsigned-removed)/20),
      adjusted:removed>0}:null,busy,error,deferred};
  }
  async function blocked(){const s=await chrome.storage.local.get({running:false,runBusy:false,refreshBusy:false,axisStatsBusyUntil:0});return s.running||s.runBusy||s.refreshBusy||s.axisStatsBusyUntil>Date.now();}
  async function refresh(force=false,identified=false){
    if(busy)return;busy=true;error='';deferred=false;let leased=false;
    const work=async lock=>{
      if(!lock){deferred=true;return;}
      if(await blocked()){deferred=true;return;}
      leased=true;await chrome.storage.local.set({axisQueueBusyUntil:Date.now()+60000});
      const me=identified&&account?account:await identify(await json('/api/me'));const id=me.id;
      if(!force&&snapshot&&Date.now()-snapshot.updatedAt<TTL)return;
      const counts={};
      for(const filter of ['unsigned','pending','signed','failed','all']){
        if(await blocked()){deferred=true;return;}
        await chrome.storage.local.set({axisQueueBusyUntil:Date.now()+60000});
        const data=await json('/api/me/history?page=1&limit=20'+(filter==='all'?'':'&filter='+filter));
        if(!Number.isInteger(data.total)||data.total<0)throw new Error('History did not return a valid total.');
        const rows=data.attempts||data.history||data.sessions||[];
        if(!Array.isArray(rows))throw new Error('Unexpected history response.');
        if(rows.some(a=>a.user_id!=null&&String(a.user_id)!==id))throw new Error('History account changed. Reopen the extension.');
        // The filter UI disappeared. Reject ignored/changed API filters instead
        // of displaying the all-history total as an unsigned count.
        const category=a=>a.txhash?'signed':a.pass_verify===true&&a.chain_data?'unsigned':a.pass_verify===false?'failed':'pending';
        if(filter!=='all' && rows.some(a=>category(a)!==filter))throw new Error('History filters changed; exact counts unavailable. Signing can still use History.');
        counts[filter]=data.total;
      }
      if(counts.unsigned+counts.pending+counts.signed+counts.failed!==counts.all)throw new Error('History totals are inconsistent; exact counts unavailable.');
      const last=await json('/api/me');
      if(String((last.data||last).id??(last.data||last).user_id)!==id){account=null;snapshot=null;throw new Error('Account changed during refresh. Reopen the extension.');}
      snapshot={counts,updatedAt:Date.now(),resolved:{}};
      await chrome.storage.local.set({[cacheKey(id)]:snapshot});
    };
    try{if(navigator.locks)await navigator.locks.request('axis-queue-counts-v151',{ifAvailable:true},work);else await work({});}
    catch(e){error=e.message;if(/filters changed|totals are inconsistent/.test(error))snapshot=null;if(/account changed/i.test(error)){account=null;snapshot=null;}}
    finally{busy=false;if(leased)await chrome.storage.local.set({axisQueueBusyUntil:0});}
  }
  async function open(){
    // Always validate which account the tab currently uses before showing its cache.
    if(busy)return view();
    try{error='';await identify(await json('/api/me'));}
    catch(e){account=null;snapshot=null;error=e.message;return view();}
    if(!snapshot||Date.now()-snapshot.updatedAt>=TTL)void refresh(false,true);
    return view();
  }
  async function resolved(id){
    if(!snapshot||!account||!id||id==='unknown')return;
    snapshot.resolved ||= {};
    if(snapshot.resolved[String(id)])return;
    snapshot.resolved[String(id)]=Date.now();
    await chrome.storage.local.set({[cacheKey(account.id)]:snapshot});
  }
  globalThis.AxisQueueCounts={open,refresh,view,identify,resolved};
  chrome.runtime.onMessage.addListener((msg,_sender,reply)=>{
    if(msg?.type==='QUEUE_STATUS'){reply({ok:true,queue:view()});return false;}
    if(msg?.type==='QUEUE_OPEN'){open().then(queue=>reply({ok:true,queue})).catch(e=>reply({ok:false,error:e.message}));return true;}
    if(msg?.type==='QUEUE_REFRESH'){void refresh(true);reply({ok:true,queue:view()});return false;}
    return false;
  });
})();
