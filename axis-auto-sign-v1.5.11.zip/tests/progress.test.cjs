const vm=require('node:vm'), fs=require('node:fs'), assert=require('node:assert/strict');
const elements=new Map();
function element(){return {textContent:'',title:'',hidden:false,disabled:false,value:'',options:[],style:{},replaceChildren(...xs){this.options=xs;}};}
const el=id=>{if(!elements.has(id)) elements.set(id,element());return elements.get(id);};
const now=Date.now();
const view={name:'test-account',updatedAt:now,epochs:[
 {period_number:1,period_start_at:new Date(now-300000).toISOString(),period_end_at:new Date(now-200000).toISOString(),status:'settled',total_points:114,task_points:114,referral_points:0,attempts:45,tasks:45,avgScore:0,scored:45},
 {period_number:2,period_start_at:new Date(now-100000).toISOString(),period_end_at:new Date(now+86400000).toISOString(),status:'pending',attempts:12,tasks:5,avgScore:87.5,scored:12}
]};
const timers=[];const calls=[];let queueBusy=true,back=0;
const context={document:{getElementById:el,createElement:element},window:{},setInterval(fn){timers.push(fn);},Date,chrome:{storage:{local:{get:async defaults=>defaults}},tabs:{query:async()=>[{id:7,url:'https://hub.axisrobotics.ai/'}],sendMessage:async(id,msg)=>{calls.push(msg.type);if(msg.type==='QUEUE_STATUS')return {ok:true,queue:{busy:queueBusy}};return {ok:true,view,status:{phase:'ready',message:'Ready'}};}}},render(){back++;}};
vm.runInNewContext(fs.readFileSync(require('node:path').join(__dirname,'../progress.js'),'utf8'),context);
(async()=>{
 await new Promise(resolve=>setImmediate(resolve));
 assert.equal(context.window.axisProgressOpen,undefined);
 assert(calls.includes('QUEUE_STATUS'),'preparation starts before Progress opens');
 assert.equal(calls.includes('EPOCH_CONNECT'),false,'queue refresh finishes first');
 queueBusy=false;await timers[0]();
 assert(calls.includes('EPOCH_CONNECT'),'summary preloaded while home remains visible');
 const connections=calls.filter(x=>x==='EPOCH_CONNECT').length;
 await el('openStats').onclick();
 assert.equal(el('app').hidden,true);assert.equal(el('progressView').hidden,false);
 assert.equal(calls.filter(x=>x==='EPOCH_CONNECT').length,connections,'opening Progress reuses prepared view');
 assert.equal(el('epochTitle').textContent,'Epoch 2');assert.equal(el('epochPoints').textContent,'Pending');
 assert.equal(el('epochAttempts').textContent,'12');assert.equal(el('epochTasks').textContent,'5');
 assert.match(el('epochRemaining').textContent,/h .*m .*s/);
 assert.equal(calls.includes('EPOCH_SYNC'),false,'fresh cache requires no history scan');
 el('epochPrevious').onclick();assert.equal(el('epochTitle').textContent,'Epoch 1');
 assert.equal(el('epochPoints').textContent,'114');assert.equal(el('epochScore').textContent,'0');
 assert.equal(el('epochRemaining').textContent,'Epoch ended');
 el('progressBack').onclick();assert.equal(context.window.axisProgressOpen,false);assert.equal(el('progressView').hidden,true);assert.equal(back,1);
 console.log('PASS: internal navigation, queue deferral, epoch selection, zero score, pending points, cache reuse, countdown');
})().catch(e=>{console.error(e);process.exitCode=1;});
