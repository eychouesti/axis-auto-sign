const assert=require('node:assert/strict');
const fs=require('node:fs');const vm=require('node:vm');const path=require('node:path');
const root=path.join(__dirname,'..');
function env(handler, initial={}){
  const data=structuredClone(initial);let listener;
  const chrome={storage:{local:{
    async get(keys){if(Array.isArray(keys))return Object.fromEntries(keys.map(k=>[k,data[k]]));if(typeof keys==='string')return {[keys]:data[keys]};return {...keys,...Object.fromEntries(Object.keys(keys).filter(k=>k in data).map(k=>[k,data[k]]))};},
    async set(v){Object.assign(data,structuredClone(v));},async remove(k){delete data[k];}
  }},runtime:{onMessage:{addListener(fn){listener=fn;}}}};
  const ctx=vm.createContext({chrome,console,Date,Map,Set,Number,Object,Array,String,Math,Promise,globalThis:null,navigator:{locks:{request:async(name,opts,fn)=>fn({})}},AxisReadAPI:{request:async p=>{const d=await handler(p);return {ok:true,status:200,json:async()=>structuredClone(d)}}}});
  ctx.globalThis=ctx;
  for(const f of ['stats-model.js','stats-content.js'])vm.runInContext(fs.readFileSync(path.join(root,f),'utf8'),ctx);
  const send=msg=>new Promise(resolve=>listener(msg,{},resolve));
  const finish=async()=>{for(let i=0;i<1000;i++){await new Promise(r=>setImmediate(r));const s=await send({type:'EPOCH_STATUS'});if(['ready','paused'].includes(s.status.phase))return s;}throw Error('Job did not finish');};
  return {data,ctx,send,finish};
}
const epoch={source:'main',period_number:4,status:'settled',period_start_at:'2026-09-11T16:00:00Z',period_end_at:'2026-09-25T16:00:00Z',task_points:2326,total_points:2326,referral_points:0};
const rows=Array.from({length:205},(_,i)=>({attempt_id:205-i,task_id:i%10,user_id:7,created_at:new Date(Date.parse('2026-09-25T15:59:00Z')-i*60000).toISOString(),is_completed:true,chain_data:{},score:i===0?null:80,verified:true,pass_verify:i===0?false:true,txhash:i===1?'0xabc':null}));
function handler(opts={}){let page3=0;return async p=>{
 if(p==='/api/me')return {id:7,username:'test'};
 if(p.includes('summary'))return {history:[epoch],next_scheduled_settle_at:'2026-10-12T16:00:00Z'};
 const page=Number(new URL(p,'https://test').searchParams.get('page'));
 if(opts.fail&&page===3&&page3++===0)throw Error('HTTP 429 — cooldown');
 let records=rows.slice((page-1)*100,page*100);
 if(opts.repeat&&page===2)records=rows.slice(0,100);
 if(opts.wrong&&page===2)records=records.map(a=>({...a,user_id:8}));
 return {total:rows.length,attempts:records};
};}
(async()=>{
 const e=env(handler());const M=e.ctx.AxisStatsModel;
 const boundary=[{...rows[0],created_at:epoch.period_start_at,score:0},{...rows[1],created_at:epoch.period_end_at,score:100}].map(M.compact);
 assert.equal(M.aggregate({history:[epoch]},boundary)[0].attempts,1,'start inclusive/end exclusive');
 assert.equal(M.aggregate({history:[epoch]},boundary)[0].avgScore,0,'zero score retained');
 assert.equal(M.counts([M.compact(rows[0])]).avgScore,null,'null score excluded');
 assert.equal(M.retryDelay('120'),120000);assert.equal(M.retryDelay(null),60000);
 assert.equal(M.retryDelay(new Date(10000).toUTCString(),0),10000);
 await e.send({type:'EPOCH_SYNC',full:true});const a=await e.finish();
 assert.equal(a.status.phase,'ready');assert.equal(a.view.counts.attempts,205);assert.equal(a.view.epochs[0].avgScore,80);assert.equal(a.view.counts.unsignedCandidates,203);assert.equal(a.view.counts.signed,1);
 assert.equal(e.data.axisStatsBusyUntil,0);assert(!e.data['axisEpochCheckpoint:7']);
 const repeated=env(handler({repeat:true}));await repeated.send({type:'EPOCH_SYNC',full:true});const b=await repeated.finish();assert.equal(b.status.phase,'paused');assert(!repeated.data['axisEpochCache:7']);
 const fail=env(handler({fail:true}));await fail.send({type:'EPOCH_SYNC',full:true});const c=await fail.finish();assert.equal(c.status.phase,'paused');assert.equal(fail.data['axisEpochCheckpoint:7'].next,3);
 await fail.send({type:'EPOCH_SYNC'});const d=await fail.finish();assert.equal(d.status.phase,'ready');assert.equal(d.view.counts.attempts,205);
 const wrong=env(handler({wrong:true}));await wrong.send({type:'EPOCH_SYNC',full:true});assert.equal((await wrong.finish()).status.phase,'paused');assert(!wrong.data['axisEpochCache:7']);
 const cache=structuredClone(e.data);cache['axisEpochCache:7'].updatedAt=0;
 const quick=env(handler(),cache);await quick.send({type:'EPOCH_SYNC'});assert.equal((await quick.finish()).view.counts.attempts,205);
 const mixedRows=rows.map((a,i)=>({...a,created_at:i<50?a.created_at:new Date(Date.parse('2026-09-10T16:00:00Z')-i*60000).toISOString()}));
 const oldCache=structuredClone(e.data);oldCache['axisEpochCache:7'].rows=mixedRows.map(M.compact);oldCache['axisEpochCache:7'].updatedAt=0;
 let requestedPages=[];
 const inc=env(async p=>{
   if(p==='/api/me')return {id:7,username:'test'};
   if(p.includes('summary'))return {history:[epoch]};
   const page=Number(new URL(p,'https://test').searchParams.get('page'));requestedPages.push(page);
   return {total:205,attempts:mixedRows.slice((page-1)*100,page*100)};
 },oldCache);
 await inc.send({type:'EPOCH_SYNC'});const incResult=await inc.finish();assert.equal(incResult.view.counts.attempts,205);assert.equal(incResult.view.epochs[0].attempts,50);assert(!requestedPages.includes(3),'quick sync retains old tail without fetching page 3');
 const latest={...epoch,period_number:5,status:'pending',period_start_at:'2026-09-25T15:30:00Z',period_end_at:'2026-10-09T16:00:00Z',total_points:null};
 const freshCache=structuredClone(oldCache);freshCache['axisEpochCache:7'].updatedAt=Date.now();
 const latestPages=[];
 const latestOnly=env(async p=>{
   if(p==='/api/me')return {id:7,username:'test'};
   if(p.includes('summary'))return {history:[epoch,latest]};
   const page=Number(new URL(p,'https://test').searchParams.get('page'));latestPages.push(page);
   return {total:205,attempts:mixedRows.slice((page-1)*100,page*100).map(r=>({...r,score:99}))};
 },freshCache);
 await latestOnly.send({type:'EPOCH_SYNC'});const latestResult=await latestOnly.finish();
 assert.equal(latestResult.status.phase,'ready');assert(latestPages.length>0,'explicit Scan refreshes even a fresh cache');
 assert(latestPages.every(p=>p===1),'stop at the first boundary page');
 assert.equal(latestResult.view.epochs.find(e=>e.period_number===5).avgScore,99);
 assert.equal(latestOnly.data['axisEpochCache:7'].rows.find(r=>r.attempt_id===160).score,80,'older epoch stays cached even when boundary page contains changed scores');
 assert.equal(latestResult.view.epochs.length,2,'new epoch automatically added');
 const isolated=env(async p=>p==='/api/me'?{id:8,username:'another'}:{history:[epoch]},e.data);const iso=await isolated.send({type:'EPOCH_CONNECT'});assert.equal(iso.view.updatedAt,null);assert.equal(iso.view.counts,null);
 console.log('PASS: epoch boundaries, null/zero scores, Retry-After, full scan, duplicates, checkpoint resume, account mismatch/isolation, quick sync.');
})().catch(e=>{console.error(e);process.exitCode=1});
