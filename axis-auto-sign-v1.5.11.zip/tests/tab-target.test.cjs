const vm=require('node:vm'),fs=require('node:fs'),assert=require('node:assert/strict');
const source=fs.readFileSync(require('node:path').join(__dirname,'../background.js'),'utf8');
const code=source.slice(source.indexOf('async function getRequestedOrActiveTab('),source.indexOf('async function pingTab('));
const youtube={id:1,url:'https://youtube.com/watch?v=test',status:'complete'};
let hubs=[{id:2,url:'https://hub.axisrobotics.ai/',status:'complete'}],updates=[];
const ctx=vm.createContext({TARGET_URL:'https://hub.axisrobotics.ai/?tab=portfolio',chrome:{tabs:{get:async id=>[youtube,...hubs].find(t=>t.id===id),query:async q=>q.url?hubs:[youtube],update:async(id,patch)=>updates.push({id,patch})}},waitForTabComplete:async id=>hubs.find(t=>t.id===id)});
vm.runInContext(code,ctx);
(async()=>{
 assert.equal((await ctx.getCurrentTabForStart(1)).id,2);
 assert.equal(updates[0].id,2);assert.equal(updates[0].patch.active,undefined,'do not steal focus');
 hubs.push({id:3,url:'https://hub.axisrobotics.ai/?tab=portfolio'});
 await assert.rejects(()=>ctx.getCurrentTabForStart(1),/Multiple Hub/);
 assert.equal((await ctx.getCurrentTabForStart(3)).id,3);
 hubs=[];await assert.rejects(()=>ctx.getCurrentTabForStart(1),/Keep a signed-in/);
 assert.equal(updates.length,1,'never navigate YouTube or pick an ambiguous account');
 console.log('PASS: background Hub targeting, no focus steal, multiple accounts, closed Hub');
})().catch(e=>{console.error(e);process.exitCode=1;});
