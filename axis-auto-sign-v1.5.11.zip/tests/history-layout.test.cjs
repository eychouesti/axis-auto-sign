const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const s=fs.readFileSync(path.join(__dirname,'../content.js'),'utf8');
const a=s.indexOf('  async function selectUnsigned('),b=s.indexOf('\n  const listRows',a);
async function check(mixed){
 const calls=[];const ctx={setStatus:async()=>{},buttons:()=>mixed?[{textContent:'Sign all'}]:[],norm:s=>s.trim(),visible:()=>true,waitFor:async f=>f(),selectFilter:async label=>{calls.push(label);return true},detect429:()=>false,halt:async()=>{throw Error('halt')},goFirstPage:async()=>calls.push('first'),updatePage:async()=>{},updateUnsignedApprox:async()=>{}};
 vm.createContext(ctx);vm.runInContext(s.slice(a,b)+';globalThis.run=selectUnsigned;',ctx);
 assert.equal(await ctx.run(),true);assert.deepEqual(calls,mixed?['first']:['Unsigned','first']);
}
(async()=>{await check(true);await check(false);assert(s.includes('if (id === "unknown") continue;'));console.log('PASS: mixed History requires no Unsigned filter, starts at page 1; legacy filter compatibility; unknown IDs excluded.');})().catch(e=>{console.error(e);process.exitCode=1});
