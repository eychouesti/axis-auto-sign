const assert=require('node:assert/strict');const vm=require('node:vm');const fs=require('node:fs');const path=require('node:path');
(async()=>{
 let store={},calls=0;
 const ctx=vm.createContext({Date,Number,Math,Promise,setTimeout,AbortSignal,navigator:{},chrome:{storage:{local:{get:async d=>({...d,...store}),set:async d=>Object.assign(store,d)}}},fetch:async()=>{calls++;return {status:429,headers:{get:()=> '120'}}}});
 vm.runInContext(fs.readFileSync(path.join(__dirname,'../stats-model.js'),'utf8'),ctx);
 vm.runInContext(fs.readFileSync(path.join(__dirname,'../read-api.js'),'utf8'),ctx);
 const now=Date.now();await ctx.AxisReadAPI.request('/api/me');
 assert(store.axisReadCooldown>=now+120000);assert.equal(store.refreshCooldownUntil,store.axisReadCooldown);
 await assert.rejects(ctx.AxisReadAPI.request('/api/me'),/Rate limited/);assert.equal(calls,1,'no network retry during cooldown');
 await assert.rejects(ctx.AxisReadAPI.request('https://elsewhere.test/'),/Unsupported/);
 console.log('PASS: Retry-After persisted; cooldown blocks network retry; non-API paths rejected.');
})().catch(e=>{console.error(e);process.exitCode=1});
