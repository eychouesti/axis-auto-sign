const assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
function env(options={}){
 let id=7,listener,requests=[],store={},locked=options.locked||false;
 const totals={unsigned:41,pending:9,signed:100,failed:3,all:153};
 const ctx=vm.createContext({Date,Math,Promise,Object,Number,String,console,navigator:{locks:{request:async(n,o,fn)=>fn(locked?null:{})}},chrome:{storage:{local:{get:async k=>typeof k==='string'?{[k]:store[k]}:{...k,...Object.fromEntries(Object.keys(k).filter(x=>x in store).map(x=>[x,store[x]]))},set:async v=>Object.assign(store,structuredClone(v))}},runtime:{onMessage:{addListener:f=>listener=f}}},AxisReadAPI:{request:async p=>{
  requests.push(p);if(options.fail && p.includes('filter=signed'))throw Error('HTTP 429');
  let data;if(p==='/api/me')data={id,username:'user'+id};else{const u=new URL(p,'https://test');const requested=u.searchParams.get('filter')||'all';const f=options.ignored?'all':requested;data={total:totals[f],attempts:[{user_id:options.wrong?8:id, ...(f==='signed'?{txhash:'0x1'}:f==='unsigned'?{pass_verify:true,chain_data:{}}:f==='failed'?{pass_verify:false}:{})}]};}
  return {ok:true,json:async()=>data};
 }}});
 vm.runInContext(fs.readFileSync(path.join(__dirname,'../queue-counts.js'),'utf8'),ctx);
 return {api:ctx.AxisQueueCounts,store,requests,setId:v=>id=v,totals};
}
const idle=async e=>{for(let n=0;n<100;n++){await new Promise(r=>setImmediate(r));if(!e.api.view().busy)return;}throw Error('busy');};
(async()=>{
 const e=env();await e.api.open();await idle(e);let q=e.api.view();assert.equal(q.snapshot.unsigned,41);assert.equal(q.snapshot.unsignedPages,3);assert.equal(q.snapshot.counts.pending,9);
 assert.equal(e.requests.filter(p=>p.includes('/history')).length,5);assert(e.requests.some(p=>p==='/api/me/history?page=1&limit=20&filter=unsigned'));
 const n=e.requests.length;await e.api.open();await idle(e);assert.equal(e.requests.length,n+1,'warm open only checks identity');
 await e.api.resolved(123);await e.api.resolved(123);assert.equal(e.api.view().snapshot.unsigned,40);assert.equal(e.api.view().snapshot.adjusted,true);
 e.setId(8);await e.api.open();await idle(e);assert.equal(e.api.view().account.id,'8');assert.equal(e.api.view().snapshot.unsigned,41);assert(e.store['axisQueueCounts:v1511:7']);assert(e.store['axisQueueCounts:v1511:8']);
 const fail=env({fail:true});await fail.api.open();await idle(fail);assert.equal(fail.api.view().snapshot,null,'no partial snapshot saved');assert.match(fail.api.view().error,/429/);
 const ignored=env({ignored:true});await ignored.api.open();await idle(ignored);assert.equal(ignored.api.view().snapshot,null);assert.match(ignored.api.view().error,/filters changed/);
 const busy=env();busy.store.running=true;await busy.api.open();await idle(busy);assert(busy.api.view().deferred);assert(!busy.requests.some(p=>p.includes('/history')));
 const wrong=env({wrong:true});await wrong.api.open();await idle(wrong);assert.equal(wrong.api.view().snapshot,null);assert.equal(wrong.api.view().account,null);
 const lock=env({locked:true});lock.store.axisQueueBusyUntil=999;await lock.api.refresh();assert.equal(lock.store.axisQueueBusyUntil,999,'other tab lease preserved');
 console.log('PASS: exact filtered requests, server totals, cache TTL, account isolation, one-time local decrement, 429 atomicity, signing deferral, cross-tab lease.');
})().catch(e=>{console.error(e);process.exitCode=1});
