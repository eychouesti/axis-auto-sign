/* One read at a time across Hub tabs; honours server cooldown. */
(() => {
  let queue=Promise.resolve();
  async function request(path) {
    if (!path.startsWith('/api/')) throw new Error('Unsupported API path');
    const run = async () => {
      const state = await chrome.storage.local.get({axisReadNotBefore:0, axisReadCooldown:0});
      if (state.axisReadCooldown>Date.now()) throw new Error(`Rate limited. Retry after ${new Date(state.axisReadCooldown).toLocaleTimeString()}`);
      await new Promise(r=>setTimeout(r,Math.max(0,state.axisReadNotBefore-Date.now())));
      await chrome.storage.local.set({axisReadNotBefore:Date.now()+1200});
      const res=await fetch(path,{credentials:'same-origin',headers:{Accept:'application/json'},signal:AbortSignal.timeout(25000)});
      if(res.status===429){
        const until=Date.now()+AxisStatsModel.retryDelay(res.headers.get('Retry-After'))+Math.random()*1000;
        await chrome.storage.local.set({axisReadCooldown:until,refreshCooldownUntil:until});
      }
      return res;
    };
    const next=queue.then(()=>navigator.locks ? navigator.locks.request('axis-read-api-v150',run) : run());
    queue=next.catch(()=>{});return next;
  }
  globalThis.AxisReadAPI={request};
})();
