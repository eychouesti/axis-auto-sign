/* Pure, conservative statistics. No point estimation or invented epoch dates. */
(() => {
  const number = v => typeof v === 'number' && Number.isFinite(v) ? v : null;
  const time = a => Date.parse(a.completed_at || a.created_at);
  function compact(a) {
    return Object.fromEntries(['attempt_id','task_id','user_id','completed_at','created_at','is_completed','score','verified','pass_verify','pass','channel','source'].map(k => [k,a[k] ?? null]).concat([['has_tx',!!a.txhash],['has_chain',!!a.chain_data]]));
  }
  function counts(rows) {
    const scored = rows.filter(a => number(a.score) !== null);
    return {
      attempts: rows.length,
      tasks: new Set(rows.filter(a=>a.task_id != null).map(a=>String(a.task_id))).size,
      completed: rows.filter(a=>a.is_completed === true).length,
      avgScore: scored.length ? scored.reduce((s,a)=>s+a.score,0)/scored.length : null,
      scored: scored.length,
      verified: rows.filter(a=>a.verified === true).length,
      passed: rows.filter(a=>a.pass_verify === true).length,
      failed: rows.filter(a=>a.pass_verify === false).length,
      pending: rows.filter(a=>a.pass_verify == null && a.verified !== true).length,
      signed: rows.filter(a=>a.has_tx).length,
      unsignedCandidates: rows.some(a=>typeof a.has_chain !== 'boolean') ? null : rows.filter(a=>a.pass_verify === true && a.has_chain && !a.has_tx).length
    };
  }
  function aggregate(summary, rows, now = Date.now()) {
    const periods = (summary.history || []).filter(e=>e.source === 'main' || (!e.source && !e.channel_slug));
    return periods.map(e=>{
      const start = Date.parse(e.period_start_at), end = Date.parse(e.period_end_at);
      const matched = rows.filter(a=>Number.isFinite(time(a)) && time(a)>=start && time(a)<end && (!a.channel || !['bnwallet','bitrobot'].includes(a.channel)));
      return {...e, ...counts(matched), current: start<=now && now<end,
        remaining: Number.isFinite(end) ? Math.max(0,end-now) : null};
    }).sort((a,b)=>Date.parse(b.period_start_at)-Date.parse(a.period_start_at));
  }
  function retryDelay(header, now=Date.now()) {
    if (header == null || header.trim()==='') return 60000;
    const n = Number(header);
    const delay = Number.isFinite(n) ? n*1000 : Date.parse(header)-now;
    return Number.isFinite(delay) ? Math.max(1000,delay) : 60000;
  }
  globalThis.AxisStatsModel = {number,time,compact,counts,aggregate,retryDelay};
})();
