// Pure rules shared with the regression tests.
(() => {
  const duplicate = /(?:already\s+(?:been\s+)?signed|already\s+(?:been\s+)?processed|duplicate\s+(?:trajectory|signature|signing)|trajectory\s+(?:is\s+)?(?:already\s+)?signed)/i;
  const classify = (message, afterApprove) => {
    // Explicit duplicate/already-signed signals are the only errors that should
    // stay permanently protected from retry.
    if (duplicate.test(message)) return 'duplicate';

    // A concrete transaction error is retryable. The content script additionally
    // treats every visible Privy "Retry transaction" modal as FAILED.
    if (afterApprove) return 'retryable';
    return 'retryable';
  };
  const retryable = (entry) => !!entry && entry.state === 'retryable';
  const eligible = (id, entry, failedOnly, queued, attempted) => !attempted.has(id) &&
    (failedOnly ? queued.has(id) && retryable(entry) : !entry);
  const resolved = (entry) => !!entry && ['signed', 'duplicate'].includes(entry.state);
  globalThis.AxisTaskState = Object.freeze({ classify, retryable, resolved, eligible });
})();
