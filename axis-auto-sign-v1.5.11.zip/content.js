// Axis Auto Sign - content script.
// The worker stays on History (mixed records or legacy Unsigned filter), saves confirmed failures for a separate retry pass,
// and keeps a persistent local ledger so a stale backend cannot make the extension pay gas twice.

(() => {
  if (window.__axisSignBotLoaded) return;
  window.__axisSignBotLoaded = true;

  // Keep the Axis page eligible for normal background execution while the user
  // is on another tab. Earlier builds had this guard, but it was accidentally
  // dropped during the refactor. A shared Web Lock also avoids blocking a
  // second Axis tab from acquiring the same keep-alive lock.
  if (navigator.locks && navigator.locks.request) {
    navigator.locks.request(
      "axis-sign-bot-keepalive",
      { mode: "shared" },
      () => new Promise(() => {})
    ).catch(() => {});
  }

  // ---------------- Config ----------------
  const CONTENT_VERSION = "1.5.11";
  const MAX_FEE_USD = 0.01;
  const FEE_WAIT_MS = 5 * 60 * 1000;
  const MAX_CONSECUTIVE_FAILS = 25;
  const UNSIGNED_REFRESH_MIN_MS = 3500;
  const UNSIGNED_REFRESH_JITTER_MS = 1500;
  const RETRY_429_MS = [30000, 60000, 120000, 240000, 300000];
  const LEDGER_KEY = "submittedIds";
  const ACCOUNT_LEDGERS_KEY = "accountLedgers";
  const ACCOUNT_SNAPSHOTS_KEY = "accountSnapshots";
  const { classify, retryable, resolved, eligible } = globalThis.AxisTaskState;

  const SEL = {
    sign: 'button[title="Client-signed (user pays gas)"]',
    close: 'button[aria-label="close modal"]',
    filterItem: ".filter-dropdown-item"
  };

  const T = {
    element: 20000,
    signButton: 3000,
    approveModal: 20000,
    result: 180000
  };

  const DEFAULTS = {
  avatarData: "", nextCycle: 0, refreshRequested: false, refreshBusy: false, refreshedAt: 0, refreshError: "", refreshTabId: null, refreshCooldownUntil: 0, activeAccountKey: "", activeAccountLabel: "", activeAccountWallet: "", accountLedgers: {}, accountSnapshots: {},
  totalSigned: null, balanceReadAt: 0, balanceUsd: null, walletEstimated: false,
    running: false, signed: 0, failed: 0, duplicateSkipped: 0, uncertain: 0,
    totalEth: 0, totalUsd: 0, usdSigned: 0, ethSigned: 0,
    spentSinceRead: 0, points: null, pending: null, waitingSign: null,
    lastError: "", status: "Idle", tabId: null, consecutiveFails: 0,
    rateLimitStreak: 0, last429ReloadAt: 0, signDelaySec: 1.7, signDelayMode: "preset", signDelayCustomSec: 1.7
  };

  // ---------------- Helpers ----------------
  class StopSignal extends Error {}
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const norm = (s) => (s || "").replace(/\s+/g, " ").trim();
  const buttons = () => [...document.querySelectorAll("button")];
  const btnByText = (t) => buttons().find((b) => norm(b.textContent) === t);
  const visible = (el) => !!el && el.getClientRects().length > 0;
  const store = (o) => chrome.storage.local.set(o);
  const jitter = () => UNSIGNED_REFRESH_MIN_MS + Math.floor(Math.random() * (UNSIGNED_REFRESH_JITTER_MS + 1));

  let running = false;
  let runPromise = null;
  let preparePromise = null;
  let ledger = Object.create(null);
  let activeAccountKey = "";
  let statsEpoch = "legacy";
  let retryPhase = false;
  let retryIds = new Set();
  const attemptedThisRun = new Set();
  let waitingIds = new Set();
  let waitingReady = false;
  const deferredUntil = new Map();
  let capturedTxError = null;

  function privyErrorModal() {
    const modal = document.getElementById("privy-modal-content");
    if (!modal || !visible(modal)) return null;
    // Privy uses this button for a transaction attempt that it considers failed.
    // Do not depend on the wording of the RPC reason: it may be nonce-too-low,
    // replacement-underpriced, generic invalid parameters, etc.
    return /Retry transaction/i.test(modal.innerText || "") ? modal : null;
  }

  function captureTxError() {
    const modal = privyErrorModal();
    if (!modal) return null;
    const text = modal.innerText || "";
    capturedTxError = { text, at: Date.now() };
    return capturedTxError;
  }

  function recentCapturedError() {
    if (!capturedTxError) return null;
    return Date.now() - capturedTxError.at <= 15000 ? capturedTxError : null;
  }

  function clearCapturedError() { capturedTxError = null; }

  function installPrivyErrorObserver() {
    if (!document.documentElement) return;
    const obs = new MutationObserver(() => { captureTxError(); });
    obs.observe(document.documentElement, { subtree: true, childList: true, characterData: true });
    captureTxError();
  }

  chrome.storage.onChanged.addListener((ch, area) => {
    if (area === "local" && ch.running) running = !!ch.running.newValue;
  });

  const check = () => { if (!running) throw new StopSignal(); };

  async function waitFor(fn, timeout = 15000, interval = 250, ignoreStop = false) {
    const end = Date.now() + timeout;
    while (true) {
      if (!ignoreStop) check();
      const v = fn();
      if (v) return v;

      const remaining = end - Date.now();
      if (remaining <= 0) break;
      // Background tabs may heavily throttle setTimeout. Never sleep past the
      // logical deadline without doing one final state check afterwards.
      await sleep(Math.min(interval, remaining));
    }

    // Critical for background-tab operation: if Chrome delayed the timer until
    // after the deadline, the DOM may already be in the desired state. The old
    // loop returned null without checking again, causing false "modal stuck".
    if (!ignoreStop) check();
    return fn() || null;
  }

  function waitForDom(fn, timeout = 7000, ignoreStop = false) {
    return new Promise((resolve, reject) => {
      let finished = false;
      let observer = null;
      let timer = null;

      const cleanup = () => {
        if (observer) observer.disconnect();
        if (timer) clearTimeout(timer);
        document.removeEventListener("visibilitychange", test);
      };

      const finish = (value) => {
        if (finished) return;
        finished = true;
        cleanup();
        resolve(value || null);
      };

      const test = () => {
        if (finished) return;
        try {
          if (!ignoreStop) check();
          const value = fn();
          if (value) finish(value);
        } catch (e) {
          finished = true;
          cleanup();
          reject(e);
        }
      };

      test();
      if (finished) return;

      observer = new MutationObserver(test);
      observer.observe(document.documentElement, {
        subtree: true,
        childList: true,
        attributes: true,
        characterData: true
      });
      document.addEventListener("visibilitychange", test);

      timer = setTimeout(() => {
        // Timers themselves may be throttled in a background tab, so always
        // evaluate the live DOM once more when the timeout finally fires.
        try {
          if (!ignoreStop) check();
          finish(fn() || null);
        } catch (e) {
          finished = true;
          cleanup();
          reject(e);
        }
      }, timeout);
    });
  }

  function click(el) {
    if (!el) return;
    el.scrollIntoView && el.scrollIntoView({ block: "center" });
    for (const type of ["pointerdown", "mousedown", "pointerup", "mouseup"]) {
      const Ctor = type.startsWith("pointer") ? PointerEvent : MouseEvent;
      el.dispatchEvent(new Ctor(type, { bubbles: true, cancelable: true, view: window }));
    }
    el.click();
  }

  const setStatus = (status) => (running ? store({ status }) : Promise.resolve());
  const halt = (status, error) => chrome.runtime.sendMessage({ type: "HALT", status, error });

  // ---------------- Persistent duplicate protection ----------------
  const fullAddress = (v) => typeof v === "string" && /^0x[a-fA-F0-9]{40}$/.test(v.trim()) ? v.trim().toLowerCase() : "";

  function walletFromObject(obj, depth = 0) {
    if (!obj || depth > 5) return "";
    if (typeof obj === "string") return fullAddress(obj);
    if (Array.isArray(obj)) {
      for (const v of obj) { const a = walletFromObject(v, depth + 1); if (a) return a; }
      return "";
    }
    if (typeof obj !== "object") return "";
    const preferred = Object.keys(obj).filter(k => /wallet|address|account/i.test(k));
    for (const k of preferred) { const a = walletFromObject(obj[k], depth + 1); if (a) return a; }
    return "";
  }

  function readProfileWallet() {
    const roots = [];
    const name = profileNameEl();
    if (name) { let r = name; for (let i = 0; r && i < 5; i++, r = r.parentElement) roots.push(r); }
    const uw = document.querySelector(".uwallet"); if (uw) roots.push(uw);
    for (const root of roots) {
      const text = [root.textContent || "", ...[...root.querySelectorAll("[title],[data-address],[data-wallet-address]")].flatMap(el => [el.getAttribute("title") || "", el.getAttribute("data-address") || "", el.getAttribute("data-wallet-address") || ""])].join(" ");
      const m = text.match(/0x[a-fA-F0-9]{40}/);
      if (m) return m[0].toLowerCase();
    }
    return "";
  }

  function readShortWallet() {
    const roots = [profileNameEl()?.parentElement, document.querySelector(".uwallet")].filter(Boolean);
    for (const root of roots) {
      const m = (root.textContent || "").match(/0x[a-fA-F0-9]{4,8}\.{2,3}[a-fA-F0-9]{4,8}/);
      if (m) return m[0].toLowerCase();
    }
    return "";
  }

  async function saveLedgerForActiveAccount() {
    if (!activeAccountKey) { await store({ [LEDGER_KEY]: ledger }); return; }
    const st = await chrome.storage.local.get({ [ACCOUNT_LEDGERS_KEY]: {} });
    const all = st[ACCOUNT_LEDGERS_KEY] && typeof st[ACCOUNT_LEDGERS_KEY] === "object" ? st[ACCOUNT_LEDGERS_KEY] : {};
    all[activeAccountKey] = ledger;
    await store({ [ACCOUNT_LEDGERS_KEY]: all, [LEDGER_KEY]: ledger });
  }

  async function activateAccount({ wallet = "", username = "", label = "" } = {}) {
    wallet = fullAddress(wallet) || readProfileWallet();
    username = norm(username || readName());
    const shortWallet = readShortWallet();
    const key = wallet ? `wallet:${wallet}` : (shortWallet ? `wallet-short:${shortWallet}|user:${username.toLowerCase()}` : (username ? `user:${username.toLowerCase()}` : ""));
    if (!key) throw new Error("Account identity not found");

    const st = await chrome.storage.local.get({ [ACCOUNT_LEDGERS_KEY]: {}, [LEDGER_KEY]: {}, activeAccountKey: "", accountSnapshots: {} });
    const all = st[ACCOUNT_LEDGERS_KEY] && typeof st[ACCOUNT_LEDGERS_KEY] === "object" ? st[ACCOUNT_LEDGERS_KEY] : {};
    // Upgrade path: assign the old single-account ledger to the account that is active during upgrade.
    if (!Object.keys(all).length && st[LEDGER_KEY] && Object.keys(st[LEDGER_KEY]).length) all[key] = st[LEDGER_KEY];
    if (!all[key]) all[key] = {};
    activeAccountKey = key;
    ledger = all[key];

    const snapshots = st.accountSnapshots && typeof st.accountSnapshots === "object" ? st.accountSnapshots : {};
    const snap = snapshots[key] || {};
    const changed = st.activeAccountKey && st.activeAccountKey !== key;
    const accountLabel = label || username || (wallet ? `${wallet.slice(0,6)}...${wallet.slice(-4)}` : shortWallet || "Account");
    const patch = {
      [ACCOUNT_LEDGERS_KEY]: all, [LEDGER_KEY]: ledger, activeAccountKey: key, activeAccountLabel: accountLabel, activeAccountWallet: wallet || shortWallet
    };
    if (changed) Object.assign(patch, {
      signed: 0, failed: 0, duplicateSkipped: 0, uncertain: 0, nextCycle: Object.values(ledger).filter(retryable).length,
      totalEth: 0, totalUsd: 0, usdSigned: 0, ethSigned: 0, spentSinceRead: 0, accumulatedMs: 0, lastResume: null,
      username: snap.username || username || "", usernameDom: snap.usernameDom || username || "", avatarData: snap.avatarData || "",
      avatarReadAt: snap.avatarReadAt || Date.now(), points: snap.points ?? null, balanceEth: snap.balanceEth ?? null,
      balanceUsd: snap.balanceUsd ?? null, walletEstimated: false, waitingSign: snap.waitingSign ?? null, pending: snap.pending ?? null,
      totalSigned: snap.totalSigned ?? null, page: null, totalPages: null, status: `Account: ${accountLabel}`
    });
    await store(patch);
    return { key, wallet, username, label: accountLabel, changed };
  }

  async function loadLedger() {
    const st0 = await chrome.storage.local.get({ activeAccountKey: "", [ACCOUNT_LEDGERS_KEY]: {}, [LEDGER_KEY]: {}, username: "", usernameDom: "" });
    if (!st0.activeAccountKey) await activateAccount({ username: st0.usernameDom || st0.username || readName() || "" });
    const s = await chrome.storage.local.get({ activeAccountKey: "", [ACCOUNT_LEDGERS_KEY]: {}, [LEDGER_KEY]: {} });
    activeAccountKey = s.activeAccountKey || activeAccountKey;
    ledger = activeAccountKey && s[ACCOUNT_LEDGERS_KEY]?.[activeAccountKey] ? s[ACCOUNT_LEDGERS_KEY][activeAccountKey] : (s[LEDGER_KEY] || Object.create(null));

    const stats = await chrome.storage.local.get({ statsEpoch: "legacy" });
    statsEpoch = stats.statsEpoch;

    // Older builds sometimes classified a visible Privy Retry-transaction modal
    // as "uncertain" (notably replacement-underpriced / nonce races). Convert
    // those stored IDs to FAILED/retryable without touching signed/duplicate IDs.
    let migratedErrors = false;
    let migratedCurrentStats = 0;
    const retryError = /nonce too low|missing or invalid parameters|replacement transaction underpriced|already known|timeout|timed out|network error|rpc request failed/i;
    for (const entry of Object.values(ledger)) {
      if (entry && entry.state === "uncertain" && retryError.test(entry.message || "")) {
        const countedThisEpoch = entry.uncertainEpoch === statsEpoch;
        entry.state = "retryable";
        entry.migratedErrorRetry = true;
        entry.ts = Date.now();
        if (countedThisEpoch) {
          entry.failedEpoch = statsEpoch;
          migratedCurrentStats += 1;
        } else {
          entry.failedEpoch = null;
        }
        migratedErrors = true;
      }
    }
    if (migratedErrors) {
      await saveLedgerForActiveAccount();
      if (migratedCurrentStats) {
        const counters = await chrome.storage.local.get(DEFAULTS);
        await store({
          failed: counters.failed + migratedCurrentStats,
          uncertain: Math.max(0, counters.uncertain - migratedCurrentStats)
        });
      }
    }
    const mode = await chrome.storage.local.get({ runMode: "normal" });
    retryPhase = mode.runMode === "failed";
    retryIds = new Set(Object.entries(ledger).filter(([, entry]) => retryable(entry)).map(([id]) => id));
    attemptedThisRun.clear();
    waitingReady = false;
    await store({ nextCycle: Object.values(ledger).filter(retryable).length });
  }

  async function setLedgerState(id, state, extra = {}) {
    if (!id || id === "unknown") return;
    ledger[id] = { ...(ledger[id] || {}), state, ts: Date.now(), ...extra };
    await saveLedgerForActiveAccount();
    await store({ nextCycle: Object.values(ledger).filter(retryable).length });
  }

  async function updateWaiting(id, remove = false) {
    if (!remove) return;
    await AxisQueueCounts.resolved(id);
    const q = AxisQueueCounts.view().snapshot;
    if (q) await store({waitingSign:q.unsigned});
  }

  async function recordDuplicate(id) {
    if (!id || id === "unknown") return;
    const entry = ledger[id] || {};
    // A row just signed by us can linger in Unsigned: do not count it twice.
    if (entry.signedEpoch === statsEpoch || entry.duplicateEpoch === statsEpoch) {
      await updateWaiting(id, true);
      return;
    }
    const s = await chrome.storage.local.get(DEFAULTS);
    await setLedgerState(id, entry.state === "signed" ? "signed" : "duplicate", { duplicateEpoch: statsEpoch });
    await store({ duplicateSkipped: s.duplicateSkipped + 1,
      failed: Math.max(0, s.failed - (entry.failedEpoch === statsEpoch ? 1 : 0)),
      consecutiveFails: 0 });
    await setLedgerState(id, ledger[id].state, { failedEpoch: null });
    await updateWaiting(id, true);
  }

  async function markUncertain(id, message) {
    const entry = ledger[id] || {};
    const s = await chrome.storage.local.get(DEFAULTS);
    await setLedgerState(id, "uncertain", { message, uncertainEpoch: statsEpoch, failedEpoch: null });
    await store({ uncertain: s.uncertain + (entry.uncertainEpoch === statsEpoch ? 0 : 1),
      failed: Math.max(0, s.failed - (entry.failedEpoch === statsEpoch ? 1 : 0)), lastError: message });
  }

  async function recordSuccess({ eth, usd }, id) {
    const entry = ledger[id] || {};
    const s = await chrome.storage.local.get(DEFAULTS);
    if (entry.signedEpoch === statsEpoch) return s.signed;
    await setLedgerState(id, "signed", { signedEpoch: statsEpoch, signedAt: Date.now(), failedEpoch: null });
    await store({
      signed: s.signed + 1,
      totalSigned: typeof s.totalSigned === "number" ? s.totalSigned + 1 : null,
      walletEstimated: true,
      failed: Math.max(0, s.failed - (entry.failedEpoch === statsEpoch ? 1 : 0)),
      totalEth: s.totalEth + (eth || 0), totalUsd: s.totalUsd + (usd || 0),
      usdSigned: s.usdSigned + (usd != null ? 1 : 0), ethSigned: s.ethSigned + (eth != null ? 1 : 0),
      spentSinceRead: s.spentSinceRead + (eth || 0), consecutiveFails: 0, rateLimitStreak: 0
    });
    await updateWaiting(id, true);
    return s.signed + 1;
  }

  async function recordFailure(message, id) {
    const entry = ledger[id] || {};
    const s = await chrome.storage.local.get(DEFAULTS);
    const consecutiveFails = s.consecutiveFails + 1;

    // Remember exactly where the failed trajectory was seen. FAILED repair runs
    // can return to that page instead of walking the whole Unsigned history.
    let retryPage = Number(currentPage());
    if (!Number.isFinite(retryPage) || retryPage < 1) retryPage = Number(s.page) || 1;

    await setLedgerState(id, "retryable", { message, failedEpoch: statsEpoch, retryPage });
    await store({ failed: s.failed + (entry.failedEpoch === statsEpoch ? 0 : 1), lastError: message, consecutiveFails });
    return consecutiveFails;
  }

  // ---------------- DOM finders ----------------
  function findHistory() {
    const cands = [...document.querySelectorAll("div, button, a, span, li")]
      .filter((e) => norm(e.textContent) === "History" && visible(e));
    return cands.find((e) => !cands.some((o) => o !== e && e.contains(o))) || null;
  }

  function rowId(btn) {
    const row = btn.closest(".axis-list-item");
    const first = row && row.firstElementChild;
    const text = norm(first && first.textContent);
    return /^#?\d+$/.test(text) ? text.replace(/^#/, "") : "unknown";
  }

  function signButtons() {
    let list = [...document.querySelectorAll(SEL.sign)];
    if (!list.length) list = buttons().filter((b) => norm(b.textContent) === "Sign");
    return list.filter((b) => !b.disabled && visible(b));
  }

  async function findSignCandidate() {
    for (const b of signButtons()) {
      const id = rowId(b);
      if (id === "unknown") continue; // Never submit without a durable deduplication ID.
      const entry = ledger[id];
      if (resolved(entry)) {
        await recordDuplicate(id);
        continue;
      }
      await updateWaiting(id);
      if (!eligible(id, entry, retryPhase, retryIds, attemptedThisRun)) continue;
      const until = deferredUntil.get(id) || 0;
      if (until > Date.now()) continue;
      if (until) deferredUntil.delete(id);
      return { button: b, id };
    }
    return null;
  }

  async function waitForSignCandidate(timeout = T.signButton) {
    const end = Date.now() + timeout;
    while (Date.now() < end) {
      check();
      const found = await findSignCandidate();
      if (found) return found;
      await sleep(250);
    }
    return null;
  }

  function ancestorWith(el, needles) {
    while (el && el !== document.body) {
      const t = el.innerText || "";
      if (needles.every((n) => t.includes(n))) return el;
      el = el.parentElement;
    }
    return null;
  }

  function approveModal() {
    const btn = btnByText("Approve");
    return btn ? ancestorWith(btn, ["Approve transaction", "Estimated fee"]) : null;
  }

  function successModal() {
    // Privy may keep a completed modal mounted in the DOM after it is closed.
    // Only treat a VISIBLE Transaction complete modal as active; otherwise a
    // stale hidden "All Done" button can make the bot think the modal is stuck.
    const btn = buttons().find((b) => norm(b.textContent) === "All Done" && visible(b));
    if (!btn) return null;
    const modal = ancestorWith(btn, ["Transaction complete!"]);
    return modal && visible(modal) ? modal : null;
  }

  function detectError() {
    const captured = captureTxError() || recentCapturedError();
    if (captured) return true;
    const retry = btnByText("Retry transaction");
    if (!retry) return false;
    const body = document.body.innerText || "";
    return body.includes("Please try again.") || body.includes("Error message") || /nonce too low/i.test(body);
  }

  function errorTextRaw() {
    const live = captureTxError();
    if (live && live.text) return live.text;
    const cached = recentCapturedError();
    if (cached && cached.text) return cached.text;
    const retry = btnByText("Retry transaction");
    const box = (retry && ancestorWith(retry, ["Please try again."])) || document.getElementById("privy-modal-content") || document.body;
    return (box && box.innerText) || "";
  }

  function extractError() {
    const text = errorTextRaw();
    // Prefer the actual RPC reason. The generic Privy 'Missing or invalid parameters'
    // line may otherwise hide the nonce race that should enter FAILED.
    const nonce = text.match(/nonce too low\s*:[^\n\r]*/i);
    if (nonce) return norm(nonce[0]);
    const lines = text.split("\n").map(norm).filter(Boolean);
    const i = lines.findIndex((l) => /^Please try again\.?$/i.test(l));
    if (i > 0) return lines[i - 1];
    const detail = lines.find((l) => /missing or invalid parameters/i.test(l));
    return detail || "Unknown transaction error";
  }

  function detect429() {
    const text = norm(document.body && document.body.innerText);
    const title = norm(document.title);
    const has429 = /\b429\b/.test(text) || /\b429\b/.test(title);
    return has429 && (/too many requests|rate limit/i.test(text + " " + title) || text.length < 1500);
  }

  // ---------------- Parsing ----------------
  function parseFee(modal) {
    if (!modal) return null;
    const m = (modal.innerText || "").match(/Estimated\s+fee\s*[:\-]?\s*([<>≤≥~≈]?)\s*\$\s*([0-9]+(?:\.[0-9]+)?)/i);
    if (!m) return null;
    const op = m[1];
    const value = parseFloat(m[2]);
    if (!Number.isFinite(value)) return null;
    const ok = value <= MAX_FEE_USD && op !== ">" && op !== "≥";
    return { op, value, ok, raw: `${op}$${m[2]}` };
  }

  function parseSuccessFees(modal) {
    const text = modal.innerText || "";
    const m = text.match(/Est\.?\s*Fees?\s*[:\-]?\s*[<~≈]?\s*([0-9]*\.?[0-9]+(?:[eE][-+]?[0-9]+)?)\s*ETH/i);
    if (!m) return { eth: null, usd: null };
    const eth = parseFloat(m[1]);
    const after = text.slice(m.index + m[0].length, m.index + m[0].length + 25);
    const u = after.match(/^[\s(]*\$\s*([0-9]+(?:\.[0-9]+)?)/);
    return { eth: Number.isFinite(eth) ? eth : null, usd: u ? parseFloat(u[1]) : null };
  }

  // ---------------- Profile / wallet / page info (display only) ----------------
  async function fetchProfile() {
    try {
      const res = await AxisReadAPI.request("/api/me");
      if (res.status === 429) return { rateLimited: true };
      if (!res.ok) return { ok: false };
      const j = await res.json();
      const d = j && j.username !== undefined ? j : (j && j.data) || j || {};
      await AxisQueueCounts.identify(d).catch(() => {});
      const patch = {};
      if (d.username) patch.username = String(d.username);
      if (typeof d.total_points === "number") patch.points = d.total_points;
      if (Object.keys(patch).length) await store(patch);
      return { ok: true, data: d, username: patch.username || "", wallet: walletFromObject(d) || walletFromObject(j) };
    } catch (_) { const c = await chrome.storage.local.get({axisReadCooldown:0}); return c.axisReadCooldown > Date.now() ? {rateLimited:true} : {ok:false}; }
  }

  const parseNum = (t) => {
    const m = (t || "").replace(/,/g, "").match(/\d+(?:\.\d+)?/);
    return m ? parseFloat(m[0]) : null;
  };

  function readTrajectories() {
    const labels = [...document.querySelectorAll("div")]
      .filter((e) => e.children.length === 0 && norm(e.textContent) === "Trajectories");
    for (const label of labels) {
      const val = (label.parentElement && label.parentElement.querySelector(".twb")) || null;
      const n = val ? parseNum(val.textContent) : null;
      if (n !== null) return n;
    }
    return null;
  }

  function readPoints() {
    const el = document.querySelector(".pts-balance-value");
    if (el) return parseNum(el.textContent);
    const label = [...document.querySelectorAll("div")].find((e) => e.children.length === 0 && norm(e.textContent) === "Points");
    return label ? parseNum(label.parentElement?.querySelector(".twb")?.textContent) : null;
  }

  function profileNameEl() {
    return [...document.querySelectorAll(".text-xl.twb")].find((el) => {
      const p = el.parentElement;
      return p && [...p.children].some((b) => b.tagName === "BUTTON" && norm(b.textContent) === "Edit");
    }) || null;
  }

  function readName() {
    const el = profileNameEl();
    return el ? norm(el.textContent) || null : null;
  }

  function readAvatar() {
    let box = profileNameEl()?.parentElement;
    // The supplied profile SVG is a sibling of the name/wallet column.
    for (let i = 0; box && box !== document.body && i < 5; i++, box = box.parentElement) {
      const img = box.querySelector('img[alt="User Avatar"]');
      if (img) {
        try {
          const url = new URL(img.currentSrc || img.getAttribute("src"), location.href);
          if (url.protocol === "https:") return url.href;
        } catch (_) { /* try the generated SVG fallback */ }
      }
      const svg = box.querySelector('svg[role="img"][viewBox="0 0 80 80"]');
      if (!svg) continue;
      const clone = svg.cloneNode(true);
      const tags = new Set(["svg", "g", "rect", "path", "circle", "ellipse", "mask", "defs", "filter", "feFlood", "feBlend", "feGaussianBlur"]);
      const attrs = new Set(["xmlns", "viewBox", "width", "height", "fill", "role", "id", "maskUnits", "filterUnits", "x", "y", "rx", "ry", "cx", "cy", "r", "d", "transform", "mask", "filter", "color-interpolation-filters", "flood-opacity", "flood-color", "result", "in", "in2", "stdDeviation", "opacity"]);
      for (const node of [clone, ...clone.querySelectorAll("*")]) {
        if (!tags.has(node.localName)) { node.remove(); continue; }
        const blend = node.style?.mixBlendMode;
        for (const attr of [...node.attributes]) {
          if (!attrs.has(attr.name) || (/url\(/i.test(attr.value) && !/^url\(#[\w-]+\)$/.test(attr.value))) node.removeAttribute(attr.name);
        }
        if (blend === "overlay") node.setAttribute("style", "mix-blend-mode:overlay");
      }
      clone.setAttribute("xmlns", "http://www.w3.org/2000/svg");
      return "data:image/svg+xml;charset=utf-8," + encodeURIComponent(new XMLSerializer().serializeToString(clone));
    }
    return "";
  }

  async function refreshStats(timeout = 0, includeApi = false) {
    if (timeout) await waitFor(() => readTrajectories() !== null || readPoints() !== null, timeout, 300, true);
    const patch = {};
    const t = readTrajectories();
    const p = readPoints();
    if (t !== null) patch.trajectories = t;
    if (p !== null) patch.points = p;
    const nm = readName();
    if (nm) { patch.usernameDom = nm; patch.avatarData = readAvatar(); patch.avatarReadAt = Date.now(); }
    if (Object.keys(patch).length) await store(patch);
    if (includeApi) return fetchProfile();
    return { ok: true };
  }

  function celebrate(n) {
    store({ bananaAt: n });
    try {
      if (!document.getElementById("axis-auto-sign-fx-style")) {
        const st = document.createElement("style");
        st.id = "axis-auto-sign-fx-style";
        st.textContent =
          "@keyframes axisBananaFall{0%{transform:translateY(0) rotate(0);opacity:0}10%{opacity:1}85%{opacity:1}" +
          "100%{transform:translateY(var(--h)) rotate(var(--r));opacity:0}}";
        document.head.appendChild(st);
      }
      const layer = document.createElement("div");
      layer.style.cssText = "position:fixed;inset:0;pointer-events:none;overflow:hidden;z-index:2147483647";
      const h = window.innerHeight + 60;
      for (let i = 0; i < 28; i++) {
        const b = document.createElement("span");
        b.textContent = "\u{1F34C}";
        const d = 2.2 + Math.random() * 1.0;
        b.style.cssText =
          `position:absolute;top:-40px;left:${Math.random() * 96}%;font-size:${16 + Math.random() * 12}px;` +
          `--h:${h}px;--r:${Math.round((Math.random() - 0.5) * 720)}deg;opacity:0;` +
          `animation:axisBananaFall ${d}s linear ${Math.random() * 1.2}s forwards`;
        layer.appendChild(b);
      }
      document.body.appendChild(layer);
      setTimeout(() => layer.remove(), 4800);
    } catch (_) { /* cosmetic only */ }
  }

  let lastPageKey = "";
  async function updatePage() {
    const nums = buttons().filter((b) => /^\d+$/.test(norm(b.textContent)) && /min-w-9/.test(b.className));
    if (!nums.length) {
      await store({ page: 1, totalPages: 1 });
      return;
    }
    const total = Math.max(...nums.map((b) => parseInt(norm(b.textContent), 10)));
    const active = nums.find((b) => /48FF88/i.test(b.className));
    const page = active ? parseInt(norm(active.textContent), 10) : 1;
    const key = `${page}/${total}`;
    if (key === lastPageKey) return;
    lastPageKey = key;
    await store({ page, totalPages: total });
  }

  async function updateUnsignedApprox() {
    // Do not infer counts from UI pages. Network refresh is owned by the queue service.
    const q = AxisQueueCounts.view().snapshot;
    if (q) await store({waitingSign:q.unsigned});
  }

  const readWalletText = () => {
    const el = document.querySelector(".uwallet .uwrow .b");
    return el ? norm(el.textContent) : null;
  };

  async function findMenuTrigger() {
    const me = await chrome.storage.local.get({ username: "" });
    const inMenu = (el) => !!el.closest(".menu, [role='dialog']");
    const clickable = (el) => el.closest("button, [role='button'], a") || el;
    const avatar = [...document.querySelectorAll("img")].find((i) => /discordapp|avatar/i.test(i.src) && !inMenu(i));
    if (avatar) return clickable(avatar);
    if (me.username) {
      const u = [...document.querySelectorAll("button, [role='button'], div, span")]
        .find((e) => norm(e.textContent) === me.username && visible(e) && !inMenu(e));
      if (u) return clickable(u);
    }
    const addr = [...document.querySelectorAll("button, [role='button'], div, span")]
      .find((e) => /^0x[0-9a-fA-F]{4}\.{2,3}[0-9a-fA-F]{4}$/.test(norm(e.textContent)) && visible(e) && !inMenu(e));
    return addr ? clickable(addr) : null;
  }

  let balanceAttemptAt = 0;
  async function refreshBalance(force = false) {
    if (!force && Date.now() - balanceAttemptAt < 30000) return;
    if (approveModal() || successModal() || detectError() || detect429()) return;
    balanceAttemptAt = Date.now();
    try {
      let text = readWalletText();
      let opened = null;
      if (!text) {
        opened = await findMenuTrigger();
        if (!opened) return;
        click(opened);
        text = await waitFor(readWalletText, 3000, 200, true);
      }
      const m = text && text.match(/([0-9]*\.?[0-9]+)\s*(?:Base\s*)?ETH/i);
      if (m) {
        const amount = parseFloat(m[1]);
        const old = await chrome.storage.local.get({ balanceEth: null, spentSinceRead: 0 });
        const walletRow = document.querySelector(".uwallet .uwrow .b")?.closest(".uwrow");
        const usdMatch = norm(walletRow?.textContent).replace(/,/g, "").match(/\$\s*(\d+(?:\.\d+)?)/);
        const patch = { balanceReadAt: Date.now() };
        // A stale identical site amount must not undo our local fee deductions.
        if (old.balanceEth === null || amount !== old.balanceEth || !old.spentSinceRead) {
          Object.assign(patch, { balanceEth: amount, spentSinceRead: 0, walletEstimated: false,
            balanceUsd: usdMatch ? Number(usdMatch[1]) : null });
        }
        await store(patch);
      }
      if (opened && document.querySelector(".uwallet")) {
        click(opened);
        await sleep(300);
        if (document.querySelector(".uwallet")) {
          document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
        }
      }
    } catch (_) { /* display-only */ }
  }

  // ---------------- Navigation / info counts ----------------
  async function openHistory(soft = false) {
    await setStatus("Loading History...");
    const el = await waitFor(findHistory, T.element, 250, soft);
    if (!el) {
      if (soft) return false;
      await halt("History tab not found", "History tab not found (are you logged in?)");
      return false;
    }
    click(el);
    await sleep(650);
    return true;
  }

  async function findFilterItem(label, soft = false) {
    const find = () => [...document.querySelectorAll(SEL.filterItem)]
      .find((e) => norm(e.textContent) === label && visible(e)) || null;
    let item = await waitFor(find, 900, 150, soft);
    if (item) return item;

    const triggers = [...document.querySelectorAll('[class*="filter-dropdown"]')].filter(
      (e) => !e.matches(".filter-dropdown-menu, .filter-dropdown-item") && !e.closest(".filter-dropdown-menu") && visible(e)
    );
    triggers.sort((a, b) => (b.matches(".filter-dropdown-trigger") ? 1 : 0) - (a.matches(".filter-dropdown-trigger") ? 1 : 0));
    for (const t of triggers) {
      click(t);
      item = await waitFor(find, 1200, 150, soft);
      if (item) return item;
    }
    return null;
  }

  async function selectFilter(label, soft = false, force = false) {
    const item = await findFilterItem(label, soft);
    if (!item) return false;
    if (force || !item.classList.contains("is-selected")) {
      const before = pageSignature();
      click(item);
      await sleep(650);
      if (detect429()) return false;
      // Give the React list a short chance to replace its rows; no full-page reload.
      await waitFor(() => pageSignature() !== before, 700, 150, true);
    }
    return true;
  }

  async function selectUnsigned(force = false) {
    await setStatus("Loading signable History records...");
    // October Hub: one mixed History table, individual Sign buttons remain.
    // Never click Sign all: it suppresses the fee review used by our gas guard.
    const mixed = await waitFor(() =>
      buttons().find(b => norm(b.textContent) === "Sign all" && visible(b)),
      1600, 150, true);
    if (!mixed) {
      // Compatibility for the earlier Hub, only when its filter actually exists.
      if (!(await selectFilter("Unsigned", false, force))) {
        if (detect429()) return false;
        await halt("History signing controls not found", "Reload the Hub History page after updating.");
        return false;
      }
    }
    await goFirstPage();
    await updatePage();
    await updateUnsignedApprox();
    return true;
  }

  const listRows = () => {
    const hov = document.querySelectorAll(".axis-list-item-hoverable");
    return (hov.length ? hov : document.querySelectorAll(".axis-list-item")).length;
  };

  const pageNumbers = () =>
    buttons().filter((b) => /^\d+$/.test(norm(b.textContent)) && /min-w-9/.test(b.className))
      .map((b) => parseInt(norm(b.textContent), 10));

  async function countStatus(label) {
    const q = AxisQueueCounts.view().snapshot;
    const key = label.toLowerCase();
    return q && Number.isInteger(q.counts[key]) ? q.counts[key] : null;
  }
  async function refreshTotalSigned() {
    const n=await countStatus("Signed"); if(n!==null)await store({totalSigned:n});
  }
  async function refreshPending() {
    const n=await countStatus("Pending"); if(n!==null)await store({pending:n});
  }
  async function refreshWaitingSign() {
    const q=AxisQueueCounts.view().snapshot; if(q)await store({waitingSign:q.unsigned});
  }

  // ---------------- Error / fee / result ----------------
  async function closeErrorModal() {
    // IMPORTANT: do not use detectError() to decide whether the modal closed.
    // detectError() intentionally keeps a short cached copy of the RPC error so
    // we can classify it after React mutates the DOM. That cache used to make a
    // successfully closed modal look "stuck" for up to 15 seconds.
    const modal = privyErrorModal() || document.getElementById("privy-modal-content");
    if (!modal || !visible(modal)) {
      clearCapturedError();
      return true;
    }

    const pressEscape = () => {
      for (const type of ["keydown", "keyup"]) {
        const ev = new KeyboardEvent(type, { key: "Escape", code: "Escape", keyCode: 27, which: 27, bubbles: true, cancelable: true });
        document.dispatchEvent(ev);
        window.dispatchEvent(new KeyboardEvent(type, { key: "Escape", code: "Escape", keyCode: 27, which: 27, bubbles: true, cancelable: true }));
      }
    };

    // Scope the X button to THIS Privy modal. document.querySelector() could
    // otherwise hit another close button elsewhere on the page.
    let x = modal.querySelector(SEL.close);
    if (x && visible(x)) click(x);
    else pressEscape();

    let closed = await waitForDom(() => !privyErrorModal(), 5000, true);
    if (!closed) {
      x = document.getElementById("privy-modal-content")?.querySelector(SEL.close);
      if (x && visible(x)) {
        try { x.click(); } catch (_) { click(x); }
      }
      pressEscape();
      closed = await waitForDom(() => !privyErrorModal(), 3500, true);
    }

    if (closed) clearCapturedError();
    return !!closed;
  }

  async function handleError(id, afterApprove) {
    const raw = errorTextRaw();
    const msg = extractError();
    let kind = classify(msg, afterApprove);

    // Final rule: a visible Privy "Retry transaction" modal is FAILED/retryable.
    // The only exception is an explicit duplicate/already-signed message, which
    // stays protected and is never retried. This mirrors the older reliable bot.
    if (afterApprove && /Retry transaction/i.test(raw)) {
      const combined = `${msg} ${raw}`;
      const duplicateLike = /already\s+(?:been\s+)?signed|already\s+(?:been\s+)?processed|duplicate\s+(?:trajectory|signature|signing)|trajectory\s+(?:is\s+)?(?:already\s+)?signed/i.test(combined);
      kind = duplicateLike ? "duplicate" : "retryable";
    }

    let fails = 0;
    if (kind === "duplicate") {
      await recordDuplicate(id);
      await setStatus(`Duplicate #${id}: skipped`);
    } else if (kind === "retryable") {
      fails = await recordFailure(msg, id);
      await setStatus(`Failed #${id}: saved for next cycle`);
    } else {
      await markUncertain(id, msg);
      await setStatus(`Check #${id}: result uncertain`);
    }

    const closed = await closeErrorModal();
    clearCapturedError();
    if (fails >= MAX_CONSECUTIVE_FAILS) {
      await halt("Stopped: too many failures", `${fails} failures in a row. Last: ${msg}`);
      return "ended";
    }
    if (!closed) {
      await halt("Stopped: error modal stuck", "The error modal would not close. No reload was attempted.");
      return "ended";
    }

    return "next";
  }

  async function handleSuccess(modal, id) {
    await setStatus(`Signed #${id}`);
    const fees = parseSuccessFees(modal);
    const n = await recordSuccess(fees, id);
    if (n % 100 === 0) celebrate(n);

    // Keep the close action scoped to the success modal. A global btnByText()
    // can hit a stale hidden Privy button left mounted by React.
    const done = [...modal.querySelectorAll("button")].find(
      (b) => norm(b.textContent) === "All Done" && visible(b)
    );
    if (done) click(done);

    // Closed means the original modal disappeared OR is no longer visible.
    // Privy frequently hides the node instead of removing it from the DOM.
    let closed = await waitForDom(
      () => !modal.isConnected || !visible(modal) || !successModal(),
      7000, true
    );

    if (!closed) {
      // Fallback 1: click the X in the same visible modal.
      let x = modal.querySelector(SEL.close);
      if (x && visible(x)) click(x);
      await sleep(250);
      closed = await waitForDom(
        () => !modal.isConnected || !visible(modal) || !successModal(),
        4000, true
      );
    }

    if (!closed) {
      // Fallback 2: Escape. Do not reload; the transaction is already recorded.
      for (const type of ["keydown", "keyup"]) {
        const ev = new KeyboardEvent(type, { key: "Escape", code: "Escape", keyCode: 27, which: 27, bubbles: true, cancelable: true });
        document.dispatchEvent(ev);
        window.dispatchEvent(new KeyboardEvent(type, { key: "Escape", code: "Escape", keyCode: 27, which: 27, bubbles: true, cancelable: true }));
      }
      closed = await waitForDom(
        () => !modal.isConnected || !visible(modal) || !successModal(),
        4000, true
      );
    }

    if (!closed) {
      // Never stop the whole bot just because Chrome throttled the hidden tab
      // before Privy finished its close animation/state update. The transaction
      // is already recorded as successful and protected in the ledger. Keep the
      // run alive, keep trying the harmless close controls, and continue as soon
      // as the visible success modal is actually gone.
      await setStatus(`Signed #${id} — waiting for success modal...`);
      let retryClose = 0;
      while (running && modal.isConnected && visible(modal) && successModal()) {
        retryClose += 1;

        const liveDone = [...modal.querySelectorAll("button")].find(
          (b) => norm(b.textContent) === "All Done" && visible(b)
        );
        if (liveDone) click(liveDone);

        if (retryClose % 2 === 0) {
          const liveX = modal.querySelector(SEL.close);
          if (liveX && visible(liveX)) click(liveX);
        }

        if (retryClose % 4 === 0) {
          for (const type of ["keydown", "keyup"]) {
            const init = { key: "Escape", code: "Escape", keyCode: 27, which: 27, bubbles: true, cancelable: true };
            document.dispatchEvent(new KeyboardEvent(type, init));
            window.dispatchEvent(new KeyboardEvent(type, init));
          }
        }

        const cleared = await waitForDom(
          () => !modal.isConnected || !visible(modal) || !successModal(),
          3000, true
        );
        if (cleared) break;
      }

      if (!running) throw new StopSignal();
      await setStatus(`Signed #${id}`);
    }
  }

  const stopWith = async (status, error) => { await halt(status, error); return "ended"; };

  async function waitOutHighFee(fee, id) {
    let x = document.querySelector(SEL.close);
    if (x) click(x);
    else document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
    await sleep(600);
    if (approveModal()) {
      return stopWith("Stopped: cannot close modal", `Fee ${fee.raw} is above $${MAX_FEE_USD} and the modal would not close.`);
    }
    const until = Date.now() + FEE_WAIT_MS;
    deferredUntil.set(id, until);
    while (Date.now() < until) {
      check();
      const left = Math.ceil((until - Date.now()) / 1000);
      const mmss = `${Math.floor(left / 60)}:${String(left % 60).padStart(2, "0")}`;
      await setStatus(`Gas high ${fee.raw}, wait ${mmss}`);
      await sleep(1000);
    }
    return "next";
  }

  // ---------------- Sign one Unsigned row ----------------
  async function signOne() {
    await updatePage();
    await setStatus("Looking for Unsigned...");
    const found = await waitForSignCandidate();
    if (!found) return "empty";

    const { button: sign, id } = found;
    clearCapturedError();
    if (id === "unknown") return stopWith("Stopped: unreadable ID", "Cannot safely identify the trajectory.");
    check();
    await setStatus(`Signing #${id}...`);
    check();
    await setLedgerState(id, "opening", { attempts: (ledger[id]?.attempts || 0) + 1 });
    check();
    attemptedThisRun.add(id);
    click(sign);

    const first = await waitFor(() => {
      const m = approveModal();
      if (m) return { type: "approve" };
      if (detectError()) return { type: "error" };
      return null;
    }, T.approveModal);

    if (!first) {
      await markUncertain(id, "No approval modal; check page manually");
      return stopWith("Stopped: modal not found", "Approve modal not found. No transaction was submitted.");
    }
    if (first.type === "error") return handleError(id, false);

    await setStatus(`Checking fee #${id}...`);
    let fee = await waitFor(() => parseFee(approveModal()), 6000);
    if (!fee) return stopWith("Stopped: fee unreadable", "Could not read the Estimated fee - stopped for safety.");
    await sleep(350);
    check();
    fee = parseFee(approveModal());
    if (!fee) return stopWith("Stopped: fee unreadable", "Could not read the Estimated fee - stopped for safety.");
    if (!fee.ok) {
      // No Approve was clicked. Restore eligibility without consuming the retry allowance.
      const attempts = Math.max(0, (ledger[id]?.attempts || 1) - 1);
      if (retryPhase) await setLedgerState(id, "retryable", { attempts });
      else { delete ledger[id]; await saveLedgerForActiveAccount(); }
      attemptedThisRun.delete(id);
      return waitOutHighFee(fee, id);
    }

    check();
    const approve = btnByText("Approve");
    if (!approve || approve.disabled) return stopWith("Stopped: Approve unavailable", "Approve button not clickable.");

    // CRITICAL: persist the ID BEFORE clicking Approve. Even if the backend remains stale,
    // only a confirmed failure can grant one later retry; ambiguous results remain blocked.
    await setLedgerState(id, "submitted", { feeUsd: fee.value });
    await setStatus(`Approving #${id}...`);
    check();
    click(approve);

    const res = await waitFor(() => {
      const sm = successModal();
      if (sm) return { type: "success", modal: sm };
      if (detectError()) return { type: "error" };
      return null;
    }, T.result, 300, true);

    if (!res) {
      await markUncertain(id, "No success/error modal after Approve");
      return stopWith("Stopped: submitted, result unknown", `#${id} was submitted and is protected from duplicate signing. Check the site manually.`);
    }
    if (res.type === "error") return handleError(id, true);
    await handleSuccess(res.modal, id);
    if (running) await refreshBalance();
    return "next";
  }

  // ---------------- Pagination / fast idle refresh ----------------
  const currentPage = () => {
    const b = buttons().find((x) => /bg-\[#48FF88\]/.test(x.className) && /^\d+$/.test(norm(x.textContent)));
    return b ? norm(b.textContent) : "";
  };

  const pageSignature = () =>
    currentPage() + "|" +
    [...document.querySelectorAll(".axis-list-item")]
      .map((r) => norm(r.firstElementChild ? r.firstElementChild.textContent : r.textContent))
      .join(",");

  async function goNextPage(soft = false) {
    const next = btnByText("Next");
    if (!next || next.disabled) return false;
    const before = pageSignature();
    await setStatus("Next History page...");
    click(next);
    const changed = await waitFor(() => pageSignature() !== before || detect429(), 8000, 250, soft);
    if (detect429()) return false;
    if (!changed) return false;
    await sleep(450);
    await updatePage();
    return true;
  }

  async function goFirstPage() {
    if (currentPage() === "1") return true;
    const first = btnByText("First") || btnByText("1");
    if (!first || first.disabled) {
      if (Number(currentPage()) > 1) throw new Error("Cannot return to first Unsigned page");
      return true; // single-page list
    }
    const before = pageSignature();
    click(first);
    const changed = await waitFor(() => pageSignature() !== before || detect429(), 6000, 200, true);
    if (!changed || detect429()) throw new Error("First page did not load");
    await sleep(350);
    await updatePage();
    return true;
  }

  async function goToUnsignedPage(targetPage) {
    targetPage = Math.max(1, Number(targetPage) || 1);
    let here = Number(currentPage()) || 1;
    if (here === targetPage) return true;

    // FAILED repair always starts from page 1. If we ever need to move backwards,
    // return there first and then move forward deterministically.
    if (here > targetPage) {
      await goFirstPage();
      here = Number(currentPage()) || 1;
    }

    // Prefer a visible numeric page button when Axis exposes the target directly.
    const direct = () => buttons().find((b) =>
      /^\d+$/.test(norm(b.textContent)) &&
      Number(norm(b.textContent)) === targetPage &&
      /min-w-9/.test(b.className) && visible(b) && !b.disabled
    );
    const directBtn = direct();
    if (directBtn && here !== targetPage) {
      const before = pageSignature();
      await setStatus(`Opening failed page ${targetPage}...`);
      click(directBtn);
      const changed = await waitFor(() => pageSignature() !== before || detect429(), 8000, 200, true);
      if (detect429()) return false;
      if (changed) {
        await sleep(350);
        await updatePage();
        if (Number(currentPage()) === targetPage) return true;
      }
    }

    // When the target page number is collapsed behind pagination ellipses, walk
    // forward with Next. This is only used by the FAILED repair pass.
    while ((Number(currentPage()) || 1) < targetPage) {
      check();
      if (detect429()) {
        const r = await recover429();
        if (r === "reloading") return false;
        continue;
      }
      await setStatus(`Opening failed page ${targetPage}...`);
      const moved = await goNextPage(true);
      if (!moved) return false;
    }
    return Number(currentPage()) === targetPage;
  }

  function isLikelyFull429Page() {
    if (!detect429()) return false;
    return !findHistory() && signButtons().length === 0 && norm(document.body.innerText).length < 12000;
  }

  async function recover429() {
    const s = await chrome.storage.local.get({ rateLimitStreak: 0, last429ReloadAt: 0 });
    const streak = Math.min((s.rateLimitStreak || 0) + 1, RETRY_429_MS.length);
    const base = RETRY_429_MS[streak - 1];
    const delay = base + Math.floor(Math.random() * 500);
    await store({ rateLimitStreak: streak });

    const cooldown = await chrome.storage.local.get({axisReadCooldown:0});
    const end = Math.max(Date.now() + delay, cooldown.axisReadCooldown);
    await store({axisReadCooldown:end});
    while (Date.now() < end) {
      check();
      const left = Math.max(1, Math.ceil((end - Date.now()) / 1000));
      await setStatus(`429, retry in ${left}s`);
      await sleep(Math.min(1000, end - Date.now()));
    }

    if (isLikelyFull429Page()) {
      const now = Date.now();
      // Full 429 document cannot soft-refresh. One controlled reload after the short delay.
      if (now - (s.last429ReloadAt || 0) >= 60000) {
        await store({ last429ReloadAt: now, status: "429 recovered, reloading once..." });
        location.reload();
        return "reloading";
      }
    }
    return "retry";
  }

  async function waitForUnsignedMutation(timeout = 1200) {
    return new Promise((resolve) => {
      let done = false;
      const finish = (v) => {
        if (done) return;
        done = true;
        obs.disconnect();
        clearTimeout(timer);
        resolve(v);
      };
      const obs = new MutationObserver(() => {
        if (signButtons().length || detect429()) finish(true);
      });
      obs.observe(document.body, { childList: true, subtree: true });
      const timer = setTimeout(() => finish(false), timeout);
    });
  }

  async function softRefreshUnsigned() {
    await setStatus("Checking new Unsigned...");
    const ok = await selectUnsigned(true);
    if (detect429()) return recover429();
    if (!ok) return "retry";
    await store({ rateLimitStreak: 0 });
    await goFirstPage();
    await updatePage();
    await updateUnsignedApprox();
    return "ok";
  }

  async function waitConfiguredSignDelay() {
    const st = await chrome.storage.local.get({ signDelaySec: 1.7, signDelayMode: "preset" });
    const sec = Math.max(st.signDelayMode === "custom" ? 0.1 : 1.7, Math.min(5, Math.round((Number(st.signDelaySec) || 1.7) * 10) / 10));
    const end = Date.now() + sec * 1000;
    await setStatus(`Delay ${sec}s before next sign...`);
    while (Date.now() < end) {
      check();
      await sleep(Math.min(250, Math.max(1, end - Date.now())));
    }
  }

  async function runFailedRepairPass() {
    // Required behavior: every FAILED repair pass begins from page 1.
    await setStatus("Failed sign: returning to page 1...");
    await goFirstPage();
    await updatePage();

    const snapshot = [...retryIds].filter((id) => retryable(ledger[id]));
    const knownPages = [...new Set(snapshot
      .map((id) => Number(ledger[id]?.retryPage))
      .filter((n) => Number.isFinite(n) && n >= 1))].sort((a, b) => a - b);
    const unknownIds = new Set(snapshot.filter((id) => !(Number(ledger[id]?.retryPage) >= 1)));

    // Process a page until no queued FAILED ID remains visible there.
    const processCurrentFailedPage = async () => {
      while (true) {
        check();
        if (detect429()) {
          const rr = await recover429();
          if (rr === "reloading") return "ended";
          continue;
        }
        const r = await signOne();
        if (r === "next") {
          await waitConfiguredSignDelay();
          continue;
        }
        if (r === "ended") return "ended";
        if (r === "empty") return "empty";
      }
    };

    // New failures have a saved page. Jump only to those pages, in ascending order.
    for (const page of knownPages) {
      check();
      if (!(await goToUnsignedPage(page))) {
        if (detect429()) continue;
        continue;
      }
      const r = await processCurrentFailedPage();
      if (r === "ended") return;
    }

    // Compatibility for FAILED IDs created by older builds before retryPage was
    // stored. Locate them once from page 1; after any new failure, its page is
    // persisted so future repair passes can jump directly there.
    if (unknownIds.size) {
      await setStatus("Locating older failed tasks...");
      await goFirstPage();
      while (true) {
        check();
        const r = await processCurrentFailedPage();
        if (r === "ended") return;

        const unresolvedUnknown = [...unknownIds].some((id) =>
          retryIds.has(id) && retryable(ledger[id]) && !attemptedThisRun.has(id));
        if (!unresolvedUnknown) break;
        if (!(await goNextPage(true))) break;
      }
    }

    // Saved page numbers can become stale if new Unsigned rows arrive above them.
    // If a queued ID was not encountered on its saved page, do one fallback scan
    // to locate it. This is still FAILED-only and never switches into normal mode.
    const stillUnattempted = () => [...retryIds].filter((id) => retryable(ledger[id]) && !attemptedThisRun.has(id));
    if (stillUnattempted().length) {
      await setStatus("Locating moved failed tasks...");
      await goFirstPage();
      while (true) {
        check();
        const r = await processCurrentFailedPage();
        if (r === "ended") return;
        if (!stillUnattempted().length) break;
        if (!(await goNextPage(true))) break;
      }
    }

    const remaining = Object.values(ledger).filter(retryable).length;
    await store({ nextCycle: remaining });
    await halt(remaining
      ? `Failed sign process completed — ${remaining} still failed`
      : "Failed sign process completed");
  }

  async function attemptLoop() {
    await loadLedger();
    if (approveModal() || successModal() || detectError()) {
      await halt("Stopped: existing transaction modal", "Resolve or close this modal before START.");
      return;
    }
    if (!(await openHistory())) return;
    // Mixed History is traversed; only individual signable rows are submitted.
    if (!(await selectUnsigned(false))) {
      if (detect429()) {
        const r = await recover429();
        if (r === "reloading") return;
      }
      if (!(await selectUnsigned(false))) return;
    }

    await updateUnsignedApprox();
    await refreshBalance();
    await store({ rateLimitStreak: 0 });

    // FAILED mode is a finite repair job. It starts on page 1, visits only the
    // saved FAILED pages (plus a one-time compatibility/fallback lookup), and
    // stops when that repair job finishes. It NEVER falls through to normal
    // Unsigned signing/searching.
    if (retryPhase) {
      await runFailedRepairPass();
      return;
    }

    while (true) {
      check();

      if (detect429()) {
        const rr = await recover429();
        if (rr === "reloading") return;
        continue;
      }

      if ((await chrome.storage.local.get({ refreshRequested: false })).refreshRequested) {
        await refreshProfileOnly();
        check();
      }
      const r = await signOne();
      if (r === "next") {
        await waitConfiguredSignDelay();
        continue;
      }
      if (r === "ended") return;

      if (r === "empty") {
        if (await goNextPage()) continue;
        if (detect429()) continue;
        const next = btnByText("Next");
        if (next && !next.disabled) return stopWith("Stopped: pagination did not advance", "Could not finish the current pass.");
        const remaining = Object.values(ledger).filter(retryable).length;
        await store({ nextCycle: remaining });
        await halt(remaining ? `Cycle done: ${remaining} failed. START SIGN FAILED` : "Cycle complete: all done");
        return;
      }
    }
  }

  let refreshPromise = null;
  async function refreshProfileOnly() {
    if (refreshPromise) return refreshPromise;
    refreshPromise = (async () => {
      await store({ refreshRequested: false, refreshBusy: true, refreshError: "" });
      try {
        if (preparePromise) await preparePromise;
        if (detect429()) throw Object.assign(new Error("RATE_LIMITED"), { rateLimited: true });

        // Account Refresh deliberately does NOT count History page-by-page.
        // It refreshes account identity/profile and wallet balance. Queue totals use the API cache.
        const api = await refreshStats(2500, true);
        if (api?.rateLimited || detect429()) throw Object.assign(new Error("RATE_LIMITED"), { rateLimited: true });
        const cur = await chrome.storage.local.get({ username: "", usernameDom: "", points: null, avatarData: "" });
        const account = await activateAccount({ wallet: api?.wallet || "", username: cur.usernameDom || api?.username || cur.username || readName() || "" });

        // Re-read after switching namespace so the new account never displays the previous user's data.
        await refreshStats(1000, false);
        await refreshBalance(true);
        if (detect429()) throw Object.assign(new Error("RATE_LIMITED"), { rateLimited: true });
        await updateUnsignedApprox();
        if (detect429()) throw Object.assign(new Error("RATE_LIMITED"), { rateLimited: true });

        const latest = await chrome.storage.local.get({
          username: "", usernameDom: "", avatarData: "", avatarReadAt: 0, points: null, balanceEth: null, balanceUsd: null,
          waitingSign: null, pending: null, totalSigned: null, accountSnapshots: {}
        });
        const snaps = latest.accountSnapshots && typeof latest.accountSnapshots === "object" ? latest.accountSnapshots : {};
        snaps[account.key] = {
          username: latest.username, usernameDom: latest.usernameDom, avatarData: latest.avatarData, avatarReadAt: latest.avatarReadAt,
          points: latest.points, balanceEth: latest.balanceEth, balanceUsd: latest.balanceUsd, waitingSign: latest.waitingSign,
          pending: latest.pending, totalSigned: latest.totalSigned, refreshedAt: Date.now()
        };
        await store({ accountSnapshots: snaps, refreshedAt: Date.now(), refreshCooldownUntil: 0, refreshError: "", status: `Account refreshed: ${account.label}` });
      } catch (e) {
        const limited = e?.rateLimited || e?.message === "RATE_LIMITED" || detect429();
        if (limited) {
          const throttle = await chrome.storage.local.get({axisReadCooldown:0});
          const until = Math.max(Date.now() + 60000, throttle.axisReadCooldown);
          await store({ refreshCooldownUntil: until, refreshError: "Rate limited — wait for the cooldown shown above", status: "Account Refresh rate limited" });
        } else {
          await store({ refreshError: String(e.message || e) });
        }
      } finally {
        await store({ refreshBusy: false, refreshTabId: null });
      }
    })().finally(() => { refreshPromise = null; });
    return refreshPromise;
  }

  // ---------------- Welcome/info preparation ----------------
  async function prepareInfo() {
    if (preparePromise) return preparePromise;
    preparePromise = (async () => {
      try {
        await store({ prepareProgress: 15 });
        const api = await refreshStats(0, true);
        if (api?.rateLimited || detect429()) {
          const throttle = await chrome.storage.local.get({axisReadCooldown:0});
          await store({ refreshCooldownUntil: Math.max(Date.now() + 60000, throttle.axisReadCooldown), refreshError: "Rate limited — wait for the cooldown shown above" });
          throw new Error("Rate limited");
        }
        const cur = await chrome.storage.local.get({ username: "", usernameDom: "" });
        await activateAccount({ wallet: api?.wallet || "", username: cur.usernameDom || api?.username || cur.username || readName() || "" });
        await store({ prepareProgress: 55 });
        await refreshBalance(true);
        // Setup reads server totals without opening History or changing its filter.
        await store({ prepareProgress: 72 });
        await AxisQueueCounts.refresh(false, true);
        await updateUnsignedApprox();
        await store({ prepareProgress: 98 });
      } catch (e) {
        console.warn("[Axis Auto Sign] prepare failed", e);
      }
      try { await chrome.runtime.sendMessage({ type: "PREPARED" }); } catch (_) { /* ignore */ }
    })().finally(() => { preparePromise = null; });
    return preparePromise;
  }

  async function allowedToRunHere() {
    let myId = null;
    try { myId = (await chrome.runtime.sendMessage({ type: "WHO" })).tabId; } catch (_) { return false; }
    for (let i = 0; i < 12; i++) {
      const st = await chrome.storage.local.get({ running: false, tabId: null });
      running = st.running;
      if (!running) return false;
      if (st.tabId === myId) return true;
      if (st.tabId !== null) return false;
      await sleep(250);
    }
    return false;
  }

  async function startRun() {
    if (runPromise) return runPromise;
    let ownsWork = false;
    runPromise = (async () => {
      const s0 = await chrome.storage.local.get({ running: false });
      running = s0.running;
      if (!running) return;
      if (!(await allowedToRunHere())) return;

      ownsWork = true;
      await store({ runBusy: true });
      try {
        if (preparePromise) await preparePromise;
        // Read display stats once. During signing we deliberately avoid repeated profile/API calls.
        await refreshStats(4000, false);
        const identity = await chrome.storage.local.get({ username: "", usernameDom: "" });
        await activateAccount({ username: identity.usernameDom || identity.username || readName() || "" });
        await sleep(500);
        await attemptLoop();
      } catch (e) {
        if (e instanceof StopSignal) return;
        console.error("[Axis Auto Sign]", e);
        await halt("Stopped: unexpected error", String((e && e.message) || e));
      }
    })().finally(async () => { if (ownsWork) await store({ runBusy: false }); runPromise = null;
      if (ownsWork && (await chrome.storage.local.get({ refreshRequested: false })).refreshRequested) await refreshProfileOnly(); });
    return runPromise;
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg) return false;
    if (msg.type === "PING_VERSION") {
      sendResponse({ ok: true, version: CONTENT_VERSION });
      return false;
    }
    if (msg.type === "REFRESH_NOW") {
      if (!runPromise) refreshProfileOnly();
      sendResponse({ ok: true });
      return false;
    }
    if (msg.type === "RUN_NOW") {
      startRun();
      sendResponse({ ok: true });
      return false;
    }
    if (msg.type === "PREPARE_NOW") {
      prepareInfo();
      sendResponse({ ok: true });
      return false;
    }
    return false;
  });

  // ---------------- Boot ----------------
  async function boot() {
    installPrivyErrorObserver();
    const s0 = await chrome.storage.local.get({ running: false, prepareTabId: null, refreshRequested: false, refreshTabId: null });
    running = s0.running;

    let myId = null;
    try { myId = (await chrome.runtime.sendMessage({ type: "WHO" })).tabId; } catch (_) { /* ignore */ }

    if (s0.refreshRequested && s0.refreshTabId === myId && !running) {
      await refreshProfileOnly();
      return;
    }
    if (s0.prepareTabId !== null && s0.prepareTabId === myId && !running) {
      await sleep(450);
      prepareInfo();
      return;
    }

    if (running) {
      startRun();
    } else {
      // Ordinary Hub visit: local DOM only. No recurring API polling.
      await sleep(500);
      refreshStats(6000, true);
    }
  }

  boot();
})();
