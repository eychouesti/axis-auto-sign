// Axis Auto Sign - background service worker.
// Owns START / STOP / RESET / HALT state transitions. The content script does the DOM work.

const TARGET_URL = "https://hub.axisrobotics.ai/?tab=portfolio";

const EXT_VERSION = chrome.runtime.getManifest().version;

async function getContentVersion(tabId) {
  try {
    const r = await chrome.tabs.sendMessage(tabId, { type: "PING_VERSION" });
    return r && r.version ? String(r.version) : null;
  } catch (_) {
    return null;
  }
}

async function waitForTabComplete(tabId, timeout = 12000) {
  const end = Date.now() + timeout;
  while (Date.now() < end) {
    try {
      const tab = await chrome.tabs.get(tabId);
      if (tab.status === "complete") return tab;
    } catch (_) { return null; }
    await new Promise(r => setTimeout(r, 250));
  }
  return null;
}

async function ensureCurrentContent(tab) {
  if (!tab || tab.id == null) return false;
  const version = await getContentVersion(tab.id);
  if (version === EXT_VERSION) return true;

  // After an extension update, Chrome does not replace an already injected
  // content script in an existing Hub tab. Reload ONLY the background Axis tab
  // once so the code handling FAILED/duplicates is guaranteed to match the popup.
  try {
    await chrome.tabs.reload(tab.id);
    await waitForTabComplete(tab.id);
    for (let i = 0; i < 20; i++) {
      const v = await getContentVersion(tab.id);
      if (v === EXT_VERSION) return true;
      await new Promise(r => setTimeout(r, 250));
    }
  } catch (_) { /* fall through */ }
  return false;
}

const DEFAULTS = {
  avatarData: "", nextCycle: 0, refreshRequested: false, refreshBusy: false, refreshedAt: 0, refreshError: "", refreshTabId: null, refreshCooldownUntil: 0, activeAccountKey: "", activeAccountLabel: "", activeAccountWallet: "", accountLedgers: {}, accountSnapshots: {},
  totalSigned: null, balanceReadAt: 0, balanceUsd: null, walletEstimated: false,
  running: false,
  runMode: "normal",
  statsEpoch: "legacy",
  runBusy: false,
  signed: 0,
  failed: 0,
  duplicateSkipped: 0,
  uncertain: 0,
  totalEth: 0,
  totalUsd: 0,
  usdSigned: 0,
  ethSigned: 0,
  spentSinceRead: 0,
  username: "",
  points: null,
  trajectories: null,
  bananaAt: 0,
  usernameDom: "",
  pending: null,
  waitingSign: null,
  welcomed: false,
  preparing: 0,
  prepareTabId: null,
  prepareProgress: 0,
  balanceEth: null,
  page: null,
  totalPages: null,
  logo: "",
  logoSrc: "",
  startedAt: null,
  accumulatedMs: 0,
  lastResume: null,
  lastError: "",
  status: "Idle",
  tabId: null,
  consecutiveFails: 0,
  rateLimitStreak: 0,
  last429ReloadAt: 0,
  signDelaySec: 1.7,
  signDelayMode: "preset",
  signDelayCustomSec: 1.7
};

const get = () => chrome.storage.local.get(DEFAULTS);
const set = (o) => chrome.storage.local.set(o);

function closeSegment(s) {
  const now = Date.now();
  return {
    accumulatedMs: s.accumulatedMs + (s.lastResume ? now - s.lastResume : 0),
    lastResume: null
  };
}

chrome.runtime.onInstalled.addListener(async (details) => {
  const cur = await chrome.storage.local.get(null);
  const missing = {};
  for (const k of Object.keys(DEFAULTS)) if (!(k in cur)) missing[k] = DEFAULTS[k];
  const patch = { ...missing, running: false, runBusy: false, refreshBusy: false, refreshRequested: false, refreshTabId: null, status: "Idle" };
  if (cur.signDelayMode !== "custom" && Number(cur.signDelaySec) < 1.7) patch.signDelaySec = 1.7;
  if (details.reason === "update") {
    patch.welcomed = true;
    patch.usernameDom = "";
    patch.preparing = 0;
    patch.prepareTabId = null;
    patch.prepareProgress = 0;
  }
  await set(patch);
});

chrome.runtime.onStartup.addListener(async () => {
  const s = await get();
  await set({ ...closeSegment(s), running: false, runBusy: false, refreshBusy: false, refreshRequested: false, refreshTabId: null, status: "Idle", tabId: null });
});

async function getRequestedOrActiveTab(requestedTabId = null) {
  let tab = null;
  if (requestedTabId != null) {
    try { tab = await chrome.tabs.get(requestedTabId); } catch (_) { tab = null; }
  }
  if (!tab) {
    let tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (!tabs.length) tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    tab = tabs && tabs[0];
  }
  const isHub = t => t?.url?.startsWith("https://hub.axisrobotics.ai/");
  if (!isHub(tab)) {
    const hubs = await chrome.tabs.query({ url: "https://hub.axisrobotics.ai/*" });
    if (hubs.length > 1) throw new Error("Multiple Hub tabs are open. Start from the Hub account you want to use.");
    tab = hubs[0];
  }
  if (!tab || tab.id == null) throw new Error("Keep a signed-in Axis Hub tab open, then try again.");
  return tab;
}

async function getCurrentTabForStart(requestedTabId = null) {
  const tab = await getRequestedOrActiveTab(requestedTabId);
  const isHub = typeof tab.url === "string" && tab.url.startsWith("https://hub.axisrobotics.ai/");
  const isPortfolio = isHub && tab.url.includes("tab=portfolio");
  if (!isPortfolio) {
    await chrome.tabs.update(tab.id, { url: TARGET_URL });
    const loaded = await waitForTabComplete(tab.id, 15000);
    if (!loaded) throw new Error("Axis Hub did not finish loading in the current tab.");
    return loaded;
  }
  return tab;
}

async function pingTab(tabId, type) {
  try {
    const r = await chrome.tabs.sendMessage(tabId, { type });
    return !!(r && r.ok);
  } catch (_) {
    return false;
  }
}

async function ensureStatsIdle() {
  const s = await chrome.storage.local.get({axisStatsBusyUntil:0,axisReadCooldown:0,axisQueueBusyUntil:0});
  if(s.axisStatsBusyUntil > Date.now() || s.axisQueueBusyUntil > Date.now()) throw new Error("Wait for counts to finish, or pause Epoch Stats sync.");
  if(s.axisReadCooldown > Date.now()) throw new Error("Cooldown active. Try again after " + new Date(s.axisReadCooldown).toLocaleTimeString());
}

async function start(mode = "normal", requestedTabId = null) {
  await ensureStatsIdle();
  const s = await get();
  if (s.running) return;
  if (s.refreshBusy || s.refreshRequested) throw new Error("Wait for refresh to finish.");
  if (s.runBusy) throw new Error("Wait for the current transaction result.");
  if (mode === "failed") {
    const st = await chrome.storage.local.get({ submittedIds: {}, activeAccountKey: "", accountLedgers: {} });
    const submittedIds = st.activeAccountKey && st.accountLedgers?.[st.activeAccountKey] ? st.accountLedgers[st.activeAccountKey] : st.submittedIds;
    const remaining = Object.values(submittedIds || {}).filter(e => e && e.state === "retryable").length;
    await set({ nextCycle: remaining });
    if (!remaining) throw new Error("No failed tasks are ready for another cycle.");
  }
  const now = Date.now();
  const tab = await getCurrentTabForStart(requestedTabId);
  const currentContent = await ensureCurrentContent(tab);
  if (!currentContent) throw new Error("Axis worker could not load the current extension version. Reload the Hub tab once.");

  await set({
    running: true,
    runMode: mode,
    status: mode === "failed" ? "Starting failed sign process..." : "Starting...",
    startedAt: s.startedAt || now,
    lastResume: s.lastResume || now,
    tabId: tab.id,
    consecutiveFails: 0
  });

  // START targets the resolved Hub tab without activating it.
  const started = await pingTab(tab.id, "RUN_NOW");
  if (!started && tab.status === "complete") {
    // One recovery navigation in the SAME current tab when its content script
    // has not attached yet (for example immediately after an extension update).
    await chrome.tabs.update(tab.id, { url: TARGET_URL });
  }
}

async function prepare(requestedTabId = null) {
  await ensureStatsIdle();
  const tab = await getRequestedOrActiveTab(requestedTabId);
  await ensureCurrentContent(tab);
  await set({ welcomed: true, preparing: Date.now(), prepareProgress: 5, prepareTabId: tab.id });

  const ok = await pingTab(tab.id, "PREPARE_NOW");
  if (!ok) {
    await set({ preparing: 0, prepareTabId: null, refreshError: "Reload the Hub tab, then try again." });
  }
}

async function refreshInfo(requestedTabId = null) {
  await ensureStatsIdle();
  const s = await get();
  if (s.refreshBusy || s.refreshRequested) return;
  if ((s.refreshCooldownUntil || 0) > Date.now()) {
    const left = Math.max(1, Math.ceil((s.refreshCooldownUntil - Date.now()) / 1000));
    throw new Error(`Rate limited — try Account Refresh again in ${left}s.`);
  }
  const tab = await getRequestedOrActiveTab(requestedTabId);
  const isHub = typeof tab.url === "string" && tab.url.startsWith("https://hub.axisrobotics.ai/");
  if (!isHub) throw new Error("Open Axis Hub in the current tab before Account Refresh.");
  await ensureCurrentContent(tab);
  await set({ refreshRequested: true, refreshTabId: tab.id, refreshError: "" });
  const ok = await pingTab(tab.id, "REFRESH_NOW");
  if (!ok && tab.status === "complete") {
    await set({ refreshRequested: false, refreshTabId: null, refreshError: "Open the Hub Portfolio tab and reload it once." });
  }
}

async function stop(status = "Stopped", error) {
  const s = await get();
  const patch = { ...closeSegment(s), running: false, status };
  if (error !== undefined) patch.lastError = error;
  await set(patch);
}

async function reset() {
  const s = await get();
  if (s.running || s.runBusy || s.refreshBusy || s.refreshRequested) throw new Error("Stop and wait for the transaction result before resetting statistics.");
  const now = Date.now();
  await set({
    statsEpoch: String(now),
    signed: 0,
    failed: 0,
    duplicateSkipped: 0,
    uncertain: 0,
    totalEth: 0,
    totalUsd: 0,
    usdSigned: 0,
    ethSigned: 0,
    bananaAt: 0,
    consecutiveFails: 0,
    lastError: "",
    accumulatedMs: 0,
    startedAt: s.running ? now : null,
    lastResume: s.running ? now : null
  });
  // Important: submittedIds is intentionally NOT reset. It is the duplicate-gas safety ledger.
}

let commandQueue = Promise.resolve();
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  commandQueue = commandQueue.then(async () => {
    try {
      switch (msg && msg.type) {
        case "REFRESH":
          await refreshInfo(msg.tabId);
          sendResponse({ ok: true });
          break;
        case "START_FAILED":
          await start("failed", msg.tabId);
          sendResponse({ ok: true });
          break;
        case "START":
          await start("normal", msg.tabId);
          sendResponse({ ok: true });
          break;
        case "STOP":
          await stop("Stopped");
          sendResponse({ ok: true });
          break;
        case "RESET":
          await reset();
          sendResponse({ ok: true });
          break;
        case "HALT": {
          const s = await get();
          if (s.running && sender.tab && sender.tab.id === s.tabId) {
            await stop(msg.status || "Stopped", msg.error);
          }
          sendResponse({ ok: true });
          break;
        }
        case "PREPARE":
          await prepare(msg.tabId);
          sendResponse({ ok: true });
          break;
        case "PREPARED": {
          const s = await get();
          if (sender.tab && sender.tab.id === s.prepareTabId) {
            await set({ preparing: 0, prepareProgress: 100, prepareTabId: null });
          }
          sendResponse({ ok: true });
          break;
        }
        case "WHO":
          sendResponse({ tabId: sender.tab ? sender.tab.id : null });
          break;
        default:
          sendResponse({ ok: false });
      }
    } catch (e) {
      sendResponse({ ok: false, error: String(e) });
    }
  });
  return true;
});

chrome.tabs.onRemoved.addListener((id) => {
  commandQueue = commandQueue.then(async () => {
    const s = await get();
    if (s.refreshTabId === id) await set({ refreshBusy: false, refreshRequested: false, refreshTabId: null, refreshError: "Hub tab closed" });
    if (s.tabId !== id) return;
    await stop("Hub tab closed; saved IDs retained");
    await set({ runBusy: false, tabId: null });
  });
});
