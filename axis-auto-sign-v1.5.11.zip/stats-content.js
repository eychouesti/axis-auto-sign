(() => {
  if (globalThis.__axisStatsLoaded) return;
  globalThis.__axisStatsLoaded=true;
  const M=AxisStatsModel;
  let busy=false, stopped=false, current=null;
  let status={phase:'idle',message:'Connect to your signed-in Hub tab.',read:0,total:null};
  const key=id=>'axisEpochCache:'+id;
  const checkpoint=id=>'axisEpochCheckpoint:'+id;
  async function json(path){
    if(stopped) throw new Error('Paused. You can resume this scan.');
    const s=await chrome.storage.local.get({running:false,runBusy:false,refreshBusy:false,axisQueueBusyUntil:0});
    if(s.running||s.runBusy||s.refreshBusy||s.axisQueueBusyUntil>Date.now()) throw new Error('Wait for queue counts to finish; pause Auto Sign / account refresh before syncing statistics.');
    await chrome.storage.local.set({axisStatsBusyUntil:Date.now()+45000});
    const r=await AxisReadAPI.request(path);
    if(!r.ok) throw new Error(`HTTP ${r.status}${r.status===429?' — cooldown saved; resume later.':''}`);
    return r.json();
  }
  async function identity(){
    const raw=await json('/api/me');const me=raw.data||raw;
    const id=me.id??me.user_id;
    if(id==null) throw new Error('Cannot identify the signed-in account.');
    return {id:String(id),name:String(me.username||id)};
  }
  async function connect(){
    current=null;
    const me=await identity();
    const saved=await chrome.storage.local.get([key(me.id),checkpoint(me.id)]);
    const cache=saved[key(me.id)];
    current={me,cache:cache?.schema===1?cache:null,hasCheckpoint:!!saved[checkpoint(me.id)]};
    // Summary is small; opening Stats never launches a history scan.
    const summary=await json('/api/me/points/summary?limit=100&source=main');
    if((await identity()).id!==me.id) {current=null;throw new Error('Account changed. Reconnect.');}
    current.summary=summary;
    return current;
  }
  const fingerprint=rows=>rows.map(a=>String(a.attempt_id)).join(',');
  function validate(data,id){
    if(!Array.isArray(data.attempts)||!Number.isInteger(data.total)||data.total<0) throw new Error('Unexpected history response.');
    if(data.attempts.some(a=>a.attempt_id==null||String(a.user_id)!==id)) throw new Error('History account mismatch or missing attempt ID.');
    if(data.total>50000) throw new Error('History exceeds this version’s 50,000-record limit; no complete total will be reported.');
  }
  async function scan(full){
    let cp=null, me=null;
    try {
      status={phase:'syncing',message:'Checking account…',read:0,total:null};
      await connect();me=current.me;
      const first=await json('/api/me/history?page=1&limit=100');validate(first,me.id);
      const saved=await chrome.storage.local.get(checkpoint(me.id));
      cp=!full?saved[checkpoint(me.id)]:null;
      if(!cp||cp.total!==first.total||cp.first!==fingerprint(first.attempts)||cp.schema!==2){
        const latestEpoch=(current.summary.history||[]).filter(e=>(e.source==='main'||(!e.source&&!e.channel_slug))&&Date.parse(e.period_start_at)<=Date.now()).sort((a,b)=>Date.parse(b.period_start_at)-Date.parse(a.period_start_at))[0];
        const cutoff=!full&&current.cache&&latestEpoch ? Date.parse(latestEpoch.period_start_at) : null;
        cp={schema:2,total:first.total,first:fingerprint(first.attempts),next:1,rows:[],cutoff:Number.isFinite(cutoff)?cutoff:null,previousTime:null};
      }
      const collected=new Map(cp.rows.map(a=>[String(a.attempt_id),a]));
      let done=false;
      for(let page=cp.next;page<=1000;page++){
        const data=page===1?first:await json(`/api/me/history?page=${page}&limit=100`);
        validate(data,me.id);
        if(data.total!==cp.total) throw new Error('History changed during sync. Pause task activity and retry.');
        let added=0;
        for(const a of data.attempts){
          const t=M.time(a);
          if(cp.cutoff!==null && (!Number.isFinite(t)||(cp.previousTime!==null&&t>cp.previousTime))) throw new Error('History order is unsuitable for quick sync. Use Full rescan.');
          cp.previousTime=Number.isFinite(t)?t:cp.previousTime;
          if((cp.cutoff===null||t>=cp.cutoff)&&!collected.has(String(a.attempt_id))){collected.set(String(a.attempt_id),M.compact(a));added++;}
        }
        cp.rows=[...collected.values()];cp.next=page+1;
        await chrome.storage.local.set({[checkpoint(me.id)]:cp});
        status={phase:'syncing',message:`Reading history · page ${page}`,read:collected.size,total:cp.total};
        if(collected.size===cp.total){done=true;break;}
        if(cp.cutoff!==null && data.attempts.length && data.attempts.some(a=>M.time(a)<cp.cutoff)){
          for(const a of current.cache.rows) if(M.time(a)<cp.cutoff&&!collected.has(String(a.attempt_id)))collected.set(String(a.attempt_id),a);
          if(collected.size!==cp.total) throw new Error('History totals changed outside the latest epoch. Use Full rescan.');
          done=true;break;
        }
        if(!added) throw new Error('Pagination repeated or ended early. No complete totals saved.');
        if(page%10===0 && (await identity()).id!==me.id) throw new Error('Account changed. Reconnect.');
      }
      if(!done)throw new Error('Scan limit reached; no complete totals saved.');
      const last=await json('/api/me/history?page=1&limit=100');validate(last,me.id);
      if(last.total!==cp.total||fingerprint(last.attempts)!==cp.first)throw new Error('History shifted while scanning. Retry without creating tasks.');
      const summary=await json('/api/me/points/summary?limit=100&source=main');
      if((await identity()).id!==me.id)throw new Error('Account changed. Reconnect.');
      const cache={schema:1,rows:[...collected.values()],total:cp.total,summary,updatedAt:Date.now(),fullScanAt:cp.cutoff===null?Date.now():current.cache.fullScanAt,recentFrom:cp.cutoff};
      await chrome.storage.local.set({[key(me.id)]:cache});
      await chrome.storage.local.remove(checkpoint(me.id));
      current={me,cache,summary,hasCheckpoint:false};
      status={phase:'ready',message:'Sync complete.',read:cache.rows.length,total:cache.total};
    }catch(e){
      status={...status,phase:'paused',message:e.message};
      if(/Account|account mismatch/.test(e.message)) current=null;
    }finally{busy=false;await chrome.storage.local.set({axisStatsBusyUntil:0});}
  }
  function snapshot(){
    if(!current)return null;
    const cache=current.cache, rows=cache?.rows||[], summary=current.summary||cache?.summary||{};
    return {name:current.me.name, accountId:current.me.id, epochs:M.aggregate(summary,rows),counts:cache?M.counts(rows):null,
      updatedAt:cache?.updatedAt||null, fullScanAt:cache?.fullScanAt||null,recentFrom:cache?.recentFrom||null,
      nextSettlement:summary.next_scheduled_settle_at,invalidDates:rows.filter(a=>!Number.isFinite(M.time(a))).length};
  }
  chrome.runtime.onMessage.addListener((msg,sender,reply)=>{
    if(!msg?.type?.startsWith('EPOCH_'))return false;
    if(msg.type==='EPOCH_STATUS'){reply({ok:true,status,view:snapshot()});return false;}
    if(msg.type==='EPOCH_PAUSE'){stopped=true;reply({ok:true});return false;}
    if(msg.type==='EPOCH_CONNECT'){
      if(busy){reply({ok:true,status,view:snapshot()});return false;}
      busy=true;stopped=false;
      connect().then(()=>{status={phase:'ready',message:'Connected. Sync to read history.',read:current.cache?.rows.length||0,total:current.cache?.total??null};reply({ok:true,status,view:snapshot()});}).catch(e=>{current=null;status={phase:'paused',message:e.message,read:0,total:null};reply({ok:false,error:e.message});}).finally(async()=>{busy=false;await chrome.storage.local.set({axisStatsBusyUntil:0});});return true;
    }
    if(msg.type==='EPOCH_SYNC'){
      if(busy){reply({ok:false,error:'A scan or connection is already running.'});return false;}
      busy=true;stopped=false;
      if(navigator.locks){
        navigator.locks.request('axis-epoch-scan-v150',{ifAvailable:true},async lock=>{
          if(!lock){busy=false;status={phase:'paused',message:'Another Hub tab is syncing statistics.',read:0,total:null};return;}
          await scan(!!msg.full);
        }).catch(e=>{busy=false;status={phase:'paused',message:e.message};});
      }else scan(!!msg.full);
      reply({ok:true});return false;
    }
    return false;
  });
})();
