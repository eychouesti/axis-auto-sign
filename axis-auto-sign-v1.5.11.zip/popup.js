const DEFAULTS = {
  avatarReadAt: 0, avatarData: "", nextCycle: 0, refreshRequested: false, refreshBusy: false, refreshedAt: 0, refreshError: "", refreshTabId: null, refreshCooldownUntil: 0, activeAccountKey: "", activeAccountLabel: "", activeAccountWallet: "", accountLedgers: {},
  totalSigned: null, balanceReadAt: 0, balanceUsd: null, walletEstimated: false,
  running: false, runBusy: false, signed: 0, failed: 0, duplicateSkipped: 0, uncertain: 0, totalEth: 0, ethSigned: 0,
  accumulatedMs: 0, lastResume: null, status: "Idle",
  username: "", usernameDom: "", points: null, pending: null, waitingSign: null,
  welcomed: false, preparing: 0, prepareProgress: 0,
  balanceEth: null, spentSinceRead: 0,
  page: null, totalPages: null, bananaAt: 0, signDelaySec: 1.7, signDelayMode: "preset", signDelayCustomSec: 1.7
};

// Fallback per-sign fee (~3 signs per $0.01) until real fees have been recorded.
const DEFAULT_FEE_ETH = 0.000001;

const $ = (id) => document.getElementById(id);
const fmtInt = (n) => Number(n).toLocaleString("en-US");
// Only touch the DOM when something actually changed (no flicker, no restarted animations).
const setText = (id, t) => { const e = $(id); if (e.textContent !== t) e.textContent = t; };
const setClass = (id, c) => { const e = $(id); if (e.className !== c) e.className = c; };

function fmtTime(ms) {
  const s = Math.max(0, Math.floor(ms / 1000));
  const p = (n) => String(n).padStart(2, "0");
  return `${p(Math.floor(s / 3600))}:${p(Math.floor((s % 3600) / 60))}:${p(s % 60)}`;
}

// Easter egg: small bananas fall from the top for ~4 seconds.
function bananas() {
  const fx = $("fx");
  const h = window.innerHeight + 40;
  for (let i = 0; i < 22; i++) {
    const b = document.createElement("span");
    b.className = "banana";
    b.textContent = "\u{1F34C}";
    b.style.left = `${Math.random() * 92}%`;
    b.style.fontSize = `${12 + Math.random() * 8}px`;
    b.style.setProperty("--h", `${h}px`);
    b.style.setProperty("--r", `${Math.round((Math.random() - 0.5) * 720)}deg`);
    b.style.animationDuration = `${2.2 + Math.random()}s`;
    b.style.animationDelay = `${Math.random() * 1.2}s`;
    fx.appendChild(b);
  }
  setTimeout(() => { fx.textContent = ""; }, 4800);
}

let prevBanana;
let failedAvatarSrc = "";
let lastAvatarReadAt = 0;
$("avatar").addEventListener("error", () => {
  failedAvatarSrc = $("avatar").getAttribute("src") || "";
  $("avatar").hidden = true;
});
$("avatar").addEventListener("load", () => {
  failedAvatarSrc = "";
  $("avatar").hidden = false;
});

async function render() {
  const s = await chrome.storage.local.get(DEFAULTS);

  // First run: welcome screen -> NEXT -> WAIT screen (until the hub is really loaded) -> normal UI.
  const waiting = !!s.preparing && Date.now() - s.preparing < 60000;
  const hasData = s.points !== null || !!s.usernameDom || s.signed > 0;
  const showWelcome = !waiting && !s.welcomed && !hasData;
  $("welcome").hidden = !showWelcome;
  $("wait").hidden = !waiting;
  $("app").hidden = showWelcome || waiting || !!window.axisProgressOpen;
  if (waiting) {
    const pct = Math.max(0, Math.min(100, Math.round(s.prepareProgress || 0)));
    setText("loadingText", `LOADING... ${pct}%`);
    $("waitBar").style.width = `${pct}%`;
    return;
  }
  if (showWelcome) return;

  // Profile: name, PTS (data arrives from the background tab opened by NEXT)
  setText("username", s.usernameDom || s.username || "-");
  const avatar = $("avatar");
  let avatarSrc = "";
  if (typeof s.avatarData === "string") {
    if (s.avatarData.startsWith("data:image/svg+xml;")) avatarSrc = s.avatarData;
    else {
      try { const url = new URL(s.avatarData); if (url.protocol === "https:") avatarSrc = url.href; } catch (_) {}
    }
  }
  const retryAvatar = s.avatarReadAt !== lastAvatarReadAt && failedAvatarSrc === avatarSrc;
  lastAvatarReadAt = s.avatarReadAt;
  if (avatar.getAttribute("src") !== avatarSrc || retryAvatar) {
    failedAvatarSrc = "";
    if (avatarSrc) avatar.src = avatarSrc; else avatar.removeAttribute("src");
  }
  avatar.hidden = !avatarSrc || failedAvatarSrc === avatarSrc;
  const cooling = (s.refreshCooldownUntil || 0) > Date.now();
  const refreshing = s.refreshRequested || s.refreshBusy;
  const refreshDisabled = refreshing || cooling;
  $("refresh").disabled = refreshDisabled;
  const cooldownLeft = cooling ? Math.max(1, Math.ceil((s.refreshCooldownUntil - Date.now()) / 1000)) : 0;
  const refreshNote = cooling ? `Rate limited — try Account Refresh again in ${cooldownLeft}s` :
    (s.refreshError || (refreshing ? (s.refreshBusy ? "Refreshing account..." : "Account refresh queued") :
    (s.refreshedAt ? `Account updated ${new Date(s.refreshedAt).toLocaleTimeString()}` : "Refresh active account")));
  $("refresh").title = refreshNote;
  $("refresh").setAttribute("aria-label", refreshNote);
  $("refresh").setAttribute("aria-busy", String(refreshing));
  $("refresh").classList.toggle("has-error", !!s.refreshError || cooling);
  setText("points", typeof s.points === "number" ? fmtInt(s.points) : "-");
  renderQueue();

  // Status
  setText("state", s.running ? "RUNNING" : "STOPPED");
  setClass("dot", s.running ? "dot on" : "dot");
  setText("signedStat", fmtInt(s.signed));
  setText("failedStat", fmtInt(s.failed));
  setText("duplicateSkipped", fmtInt(s.duplicateSkipped));


  // Pages
  if (s.page && s.totalPages) {
    setText("page", `${s.page} / ${s.totalPages}`);
    $("pageBar").style.width = `${Math.min(100, (s.page / s.totalPages) * 100)}%`;
  } else {
    setText("page", "-");
    $("pageBar").style.width = "0";
  }

  const elapsed = s.accumulatedMs + (s.running && s.lastResume ? Date.now() - s.lastResume : 0);
  setText("elapsed", fmtTime(elapsed));
  const currentText = cooling ? `Rate limited — Account Refresh in ${cooldownLeft}s` : (s.refreshError || s.status || "Idle");
  setText("current", currentText);
  $("current").title = currentText;

  $("start").disabled = s.running || s.runBusy || refreshDisabled;
  $("startFailed").disabled = s.running || s.runBusy || refreshDisabled || !s.nextCycle;
  $("stop").disabled = !s.running;
  $("reset").disabled = s.running || s.runBusy || refreshDisabled;

  const normalizeCustomDelay = (value, fallback = 1.7) => {
    const normalized = String(value ?? "").trim().replace(",", ".");
    const n = Number(normalized);
    if (!Number.isFinite(n) || n <= 0) return fallback;
    return Math.min(5, Math.round(n * 10) / 10);
  };
  const rawDelay = Math.min(5, Math.max(s.signDelayMode === "custom" ? 0.1 : 1.7, Math.round((Number(s.signDelaySec) || 1.7) * 10) / 10));
  const customValue = normalizeCustomDelay(s.signDelayCustomSec, rawDelay || 1.7);
  const customMode = s.signDelayMode === "custom";
  for (const input of document.querySelectorAll('input[name="signDelay"]')) {
    input.checked = input.value === "custom" ? customMode : (!customMode && Number(input.value) === rawDelay);
    input.disabled = s.running || s.runBusy;
  }
  const customDelay = $("customDelay");
  if (document.activeElement !== customDelay) customDelay.value = String(customValue);
  customDelay.disabled = s.running || s.runBusy;
  customDelay.classList.toggle("active", customMode);

  // Easter egg: fires when a new multiple of 100 signs was reached while the popup is open.
  if (prevBanana !== undefined && s.bananaAt > 0 && s.bananaAt !== prevBanana) bananas();
  prevBanana = s.bananaAt;
}

const send = async (type, extra = {}) => {
  try {
    const result = await chrome.runtime.sendMessage({ type, ...extra });
    await render();
    if (!result.ok) setText("current", result.error || "Action unavailable");
  } catch (e) { setText("current", String(e.message || e)); }
};

async function getActiveBrowserTabId() {
  let tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (!tabs.length) tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const tabId = tabs && tabs[0] && tabs[0].id;
  if (tabId == null) throw new Error("No active browser tab found.");
  return tabId;
}

async function sendFromCurrentTab(type) {
  try {
    const tabId = await getActiveBrowserTabId();
    await send(type, { tabId });
  } catch (e) {
    setText("current", String(e.message || e));
  }
}

async function sendStart(type) {
  return sendFromCurrentTab(type);
}

$("refresh").addEventListener("click", () => sendFromCurrentTab("REFRESH"));
$("next").addEventListener("click", () => sendFromCurrentTab("PREPARE"));
$("startFailed").addEventListener("click", () => sendStart("START_FAILED"));
$("start").addEventListener("click", () => sendStart("START"));
for (const input of document.querySelectorAll('input[name="signDelay"]')) {
  input.addEventListener("change", async () => {
    if (!input.checked) return;
    if (input.value === "custom") {
      const box = $("customDelay");
      const normalized = String(box.value || "").trim().replace(",", ".");
      let sec = Number(normalized);
      if (!Number.isFinite(sec) || sec <= 0) sec = 1.7;
      sec = Math.min(5, Math.round(sec * 10) / 10);
      box.value = String(sec);
      await chrome.storage.local.set({ signDelayMode: "custom", signDelayCustomSec: sec, signDelaySec: sec });
    } else {
      const sec = Number(input.value);
      if (![1.7, 2, 2.5].includes(sec)) return;
      await chrome.storage.local.set({ signDelayMode: "preset", signDelaySec: sec });
    }
    await render();
  });
}

const parseCustomDelay = (value) => {
  const normalized = String(value ?? "").trim().replace(",", ".");
  const sec = Number(normalized);
  if (!Number.isFinite(sec) || sec <= 0) return null;
  return Math.min(5, Math.round(sec * 10) / 10);
};

const saveCustomDelay = async () => {
  const box = $("customDelay");
  const current = await chrome.storage.local.get({ signDelayCustomSec: 1.7 });
  let sec = parseCustomDelay(box.value);
  if (sec == null) sec = parseCustomDelay(current.signDelayCustomSec) || 1.7;
  box.value = String(sec);
  await chrome.storage.local.set({ signDelayMode: "custom", signDelayCustomSec: sec, signDelaySec: sec });
  const customRadio = document.querySelector('input[name="signDelay"][value="custom"]');
  if (customRadio) customRadio.checked = true;
  await render();
};
$("customDelay").addEventListener("focus", async () => {
  if ($("customDelay").disabled) return;
  const customRadio = document.querySelector('input[name="signDelay"][value="custom"]');
  if (customRadio && !customRadio.checked) {
    customRadio.checked = true;
    await saveCustomDelay();
  }
});
$("customDelay").addEventListener("input", () => {
  const box = $("customDelay");
  let value = box.value.replace(/[^0-9.,]/g, "");
  const firstSep = value.search(/[.,]/);
  if (firstSep >= 0) {
    value = value.slice(0, firstSep + 1) + value.slice(firstSep + 1).replace(/[.,]/g, "");
  }
  const parsed = Number(value.replace(",", "."));
  if (Number.isFinite(parsed) && parsed > 5) value = "5";
  box.value = value;
});
$("customDelay").addEventListener("change", saveCustomDelay);
$("customDelay").addEventListener("blur", saveCustomDelay);
$("stop").addEventListener("click", () => send("STOP"));
$("reset").addEventListener("click", () => send("RESET"));

chrome.storage.onChanged.addListener(render);
setInterval(render, 1000);
render();

// API queue counts: validate account once per popup opening, then poll only local state.
let queueTabId = null, queueData = null, queuePollBusy = false;
function renderQueue() {
  const q=queueData?.snapshot;
  setText("waitingSign", q ? `${q.adjusted ? "≈ " : ""}${fmtInt(q.unsigned)}` : "—");
  for(const [id,key] of [["queuePending","pending"],["queueSigned","signed"],["queueFailed","failed"]])setText(id,q?fmtInt(q.counts[key]):"—");
  setText("queuePages",q?`${q.adjusted ? "≈ " : ""}${fmtInt(q.unsignedPages)}`:"—");
  let note=queueData?.error || (queueData?.busy ? "Updating counts…" : queueData?.deferred ? "Cached counts · refresh after signing / stats sync" : q ? `Updated · ${new Date(q.updatedAt).toLocaleTimeString()}${q.adjusted ? " · locally adjusted" : ""}` : "Open your signed-in Hub tab");
  if(queueData?.account)note=`${queueData.account.name} · ${note}`;
  setText("queueNote",note);
  $("queueRefresh").disabled=!!queueData?.busy || !queueTabId;
}
async function queueSend(type) {
  if(!queueTabId || queuePollBusy)return;
  queuePollBusy=true;
  try{const r=await chrome.tabs.sendMessage(queueTabId,{type});if(r?.ok)queueData=r.queue;else queueData={error:r?.error||"Counts unavailable"};}
  catch{queueData={error:"Reload the Hub tab after updating the extension."};}
  finally{queuePollBusy=false;renderQueue();}
}
async function initQueue(){
  const active=await chrome.tabs.query({active:true,currentWindow:true});
  let tab=active.find(t=>t.url?.startsWith("https://hub.axisrobotics.ai/"));
  if(!tab){const hubs=await chrome.tabs.query({url:"https://hub.axisrobotics.ai/*"});if(hubs.length===1)tab=hubs[0];}
  queueTabId=tab?.id||null;
  if(queueTabId)await queueSend("QUEUE_OPEN");else renderQueue();
}
$("queueRefresh").onclick=()=>queueSend("QUEUE_REFRESH");
setInterval(()=>queueSend("QUEUE_STATUS"),1500);
window.axisQueueReady = initQueue();
