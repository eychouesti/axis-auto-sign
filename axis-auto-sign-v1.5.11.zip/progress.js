/* Internal popup view. Polling reads content-script state, not the remote API. */
(() => {
  const el = id => document.getElementById(id);
  const put = (id, value) => { el(id).textContent = value; el(id).title = String(value); };
  const fmt = value => typeof value === 'number' && Number.isFinite(value) ? value.toLocaleString(undefined, { maximumFractionDigits: 2 }) : '—';
  const date = value => Number.isFinite(Date.parse(value)) ? new Date(value).toLocaleString(undefined, {year:'numeric',month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'}) : '—';
  const key = e => `${e.period_number}:${e.period_start_at}`;
  let tabId = null, view = null, selected = null, status = {}, busy = false, connected = false, error = '', signature = '';
  const epochs = () => [...(view?.epochs || [])].sort((a,b) => Date.parse(a.period_start_at)-Date.parse(b.period_start_at));
  async function send(type, extra = {}) {
    if (!tabId) throw new Error('Open your signed-in Hub tab, then reopen Progress.');
    let result;
    try { result = await chrome.tabs.sendMessage(tabId, {type, ...extra}); }
    catch { throw new Error('Reload the Hub tab after updating the extension.'); }
    if (!result?.ok) throw new Error(result?.error || 'Hub did not respond.');
    return result;
  }
  function accept(result) { if ('view' in result) view = result.view; if (result.status) status = result.status; }
  function renderProgress() {
    if (!window.axisProgressOpen) return;
    const list = epochs();
    if (!list.some(e => key(e) === selected)) selected = list.length ? key(list.find(e => Date.parse(e.period_start_at)<=Date.now() && Date.now()<Date.parse(e.period_end_at)) || list[list.length-1]) : null;
    const sig = list.map(e=>`${key(e)}:${e.status}`).join('|');
    if (sig !== signature || !el('epochSelect').options.length) {
      signature = sig;
      const options = list.map(e => { const option = document.createElement('option'); option.value = key(e); option.textContent = `Epoch ${e.period_number} · ${e.status === 'settled' ? 'Settled' : 'Pending'}`; return option; });
      if (!options.length) { const option = document.createElement('option'); option.textContent = 'No epochs loaded'; options.push(option); }
      el('epochSelect').replaceChildren(...options);
    }
    if (selected) el('epochSelect').value = selected;
    const index = list.findIndex(e=>key(e)===selected), e = list[index];
    el('epochSelect').disabled = !list.length;
    el('epochPrevious').disabled = index <= 0;
    el('epochNext').disabled = index < 0 || index >= list.length-1;
    put('progressAccount', view?.name || 'Axis Hub');
    for (const id of ['epochTitle','epochStatus','epochFrom','epochTo','epochPoints','epochAttempts','epochTasks','epochScore','epochRemaining']) put(id,'—');
    el('epochTimeBar').style.width = '0%';
    if (e) {
      const start = Date.parse(e.period_start_at), end = Date.parse(e.period_end_at), now = Date.now();
      const active = start <= now && now < end;
      put('epochTitle', `Epoch ${e.period_number}`);
      put('epochStatus', active ? 'IN PROGRESS' : e.status === 'settled' ? 'SETTLED' : 'PENDING');
      put('epochFrom',date(e.period_start_at)); put('epochTo',date(e.period_end_at));
      put('epochPoints', e.status === 'settled' ? fmt(e.total_points) : 'Pending');
      put('epochPointsNote',e.status === 'settled' ? `Task ${fmt(e.task_points)} · Referral ${fmt(e.referral_points)}` : 'Calculated after settlement');
      put('epochAttempts',view.updatedAt ? fmt(e.attempts) : '—');
      put('epochTasks',view.updatedAt ? fmt(e.tasks) : '—');
      put('epochScore',view.updatedAt ? fmt(e.avgScore) : '—');
      put('epochScoreNote',view.updatedAt ? `${fmt(e.scored)} scored records` : 'Sync history to see scores');
      put('remainingLabel',now < start ? 'STARTS IN' : 'REMAINING TIME');
      if (Number.isFinite(start) && Number.isFinite(end)) {
        const sec = Math.max(0,Math.floor(((now < start ? start : end)-now)/1000));
        put('epochRemaining',now >= end ? 'Epoch ended' : `${Math.floor(sec/86400)}d ${String(Math.floor(sec/3600)%24).padStart(2,'0')}h ${String(Math.floor(sec/60)%60).padStart(2,'0')}m ${String(sec%60).padStart(2,'0')}s`);
        el('epochTimeBar').style.width = `${end > start ? Math.min(100,Math.max(0,(now-start)/(end-start)*100)) : 0}%`;
      }
    }
    put('progressMessage',error || status.message || 'Connecting…');
    put('progressUpdated',status.phase === 'syncing' ? `${fmt(status.read)} / ${fmt(status.total)} records read` : view?.updatedAt ? `History updated ${date(new Date(view.updatedAt).toISOString())}` : 'History has not been synced.');
    el('syncProgressBar').style.width = `${status.total > 0 ? Math.min(100,(status.read||0)/status.total*100) : 0}%`;
    el('progressSync').disabled = busy || status.phase === 'syncing';
    el('progressFull').disabled = busy || status.phase === 'syncing';
    el('progressPause').disabled = status.phase !== 'syncing';
  }
  async function connect() {
    const activity = await chrome.storage.local.get({running:false,runBusy:false,refreshBusy:false,preparing:0});
    if (activity.running || activity.runBusy || activity.refreshBusy || activity.preparing) {
      status = {message:'Waiting for signing / account setup to finish…'}; return false;
    }
    const queue = await send('QUEUE_STATUS');
    if (queue.queue?.busy) { status = {message:'Updating queue totals first…'}; return false; }
    const existing = await send('EPOCH_STATUS');
    if (existing.status?.phase === 'syncing') { accept(existing); connected = true; return true; }
    accept(await send('EPOCH_CONNECT')); connected = true;
    if (!view?.updatedAt || Date.now()-view.updatedAt > 300000) {
      await send('EPOCH_SYNC'); accept(await send('EPOCH_STATUS'));
    }
    return true;
  }
  async function poll() {
    if (busy || !tabId) return;
    busy = true;
    try { if (!connected) await connect(); else accept(await send('EPOCH_STATUS')); error = ''; }
    catch (e) { error = e.message; connected = true; }
    finally { busy = false; renderProgress(); }
  }
  async function action(type, extra) {
    if (busy) return;
    busy = true; error = ''; renderProgress();
    try {
      if (!view) { const ready = await connect(); if (!ready) return; }
      await send(type,extra); accept(await send('EPOCH_STATUS'));
    } catch(e) { error = e.message; }
    finally { busy = false; renderProgress(); }
  }
  // Prepare once as soon as the popup opens. Queue totals have priority.
  const ready = (async () => {
    try {
      await window.axisQueueReady;
      const active = await chrome.tabs.query({active:true,currentWindow:true});
      let tab = active.find(t=>t.url?.startsWith('https://hub.axisrobotics.ai/'));
      if (!tab) { const hubs = await chrome.tabs.query({url:'https://hub.axisrobotics.ai/*'}); if (hubs.length === 1) tab = hubs[0]; }
      tabId = tab?.id || null;
      if (!tabId) throw new Error('Open your signed-in Hub tab, then reopen the extension.');
      await poll();
    } catch(e) { error=e.message; renderProgress(); }
  })();
  el('openStats').onclick = async () => {
    window.axisProgressOpen = true;
    for (const id of ['app','welcome','wait']) el(id).hidden = true;
    el('progressView').hidden = false; renderProgress();
    await ready;
    await poll();
  };
  el('progressBack').onclick = () => { window.axisProgressOpen = false; el('progressView').hidden = true; render(); };
  el('epochSelect').onchange = () => { selected = el('epochSelect').value; renderProgress(); };
  for (const [id, delta] of [['epochPrevious',-1],['epochNext',1]]) el(id).onclick = () => { const list=epochs(), i=list.findIndex(e=>key(e)===selected); if (list[i+delta]) selected=key(list[i+delta]); renderProgress(); };
  el('progressSync').onclick = () => action('EPOCH_SYNC');
  el('progressFull').onclick = () => action('EPOCH_SYNC',{full:true});
  el('progressPause').onclick = () => action('EPOCH_PAUSE');
  setInterval(poll,1800); setInterval(renderProgress,1000);
})();
